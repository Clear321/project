# train_progressive.py
"""
渐进式训练，从简单到复杂
"""
import sys
from pathlib import Path

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))


def run_progressive_training():
    """渐进式训练"""

    print("=" * 60)
    print("渐进式训练方案")
    print("=" * 60)

    print("\n阶段1: 验证基础环境")
    print("-" * 40)

    # 测试基础PyTorch
    import torch
    print(f"PyTorch版本: {torch.__version__}")
    print(f"CUDA可用: {torch.cuda.is_available()}")

    # 测试数据加载
    try:
        from safe_dataset import test_safe_dataset
        test_safe_dataset()
        print("✓ 数据加载测试通过")
    except Exception as e:
        print(f"✗ 数据加载测试失败: {e}")
        return False

    print("\n阶段2: 简单模型训练")
    print("-" * 40)

    try:
        # 导入简化训练
        from train_simple import main as simple_main
        print("运行简化训练...")
        simple_main()
        print("✓ 简单训练完成")
    except Exception as e:
        print(f"✗ 简单训练失败: {e}")
        return False

    print("\n阶段3: 增加复杂度")
    print("-" * 40)

    # 这里可以逐步增加模型复杂度

    print("\n✅ 渐进式训练完成!")
    print("\n下一步:")
    print("1. 检查 runs/simple/ 目录中的模型")
    print("2. 尝试增加训练轮数")
    print("3. 尝试增加图像尺寸")
    print("4. 逐步使用更复杂的模型")

    return True


if __name__ == "__main__":
    run_progressive_training()