# train_simple.py
"""
简化版训练脚本，避免复杂问题
"""
import os
import sys
from pathlib import Path
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import yaml
import numpy as np

# ============ 1. 设置项目环境 ============

# 设置项目根目录
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))
os.chdir(project_root)

print("=" * 60)
print("YOLOv9接触网异物检测 - 简化训练版本")
print("=" * 60)


# ============ 2. 创建简单的模型 ============

class SimpleDetector(nn.Module):
    """简化的检测器模型"""

    def __init__(self, num_classes=2):
        super().__init__()
        self.num_classes = num_classes

        # 简化特征提取
        self.backbone = nn.Sequential(
            nn.Conv2d(3, 16, kernel_size=3, padding=1),
            nn.BatchNorm2d(16),
            nn.ReLU(),
            nn.MaxPool2d(2),  # 160x160

            nn.Conv2d(16, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(2),  # 80x80
        )

        # 检测头
        self.cls_head = nn.Sequential(
            nn.Conv2d(32, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(32, num_classes, kernel_size=1)
        )

        self.reg_head = nn.Sequential(
            nn.Conv2d(32, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(32, 4, kernel_size=1),  # x, y, w, h
            nn.Sigmoid()  # 输出在0-1之间
        )

    def forward(self, x):
        # 提取特征
        features = self.backbone(x)  # [B, 32, 80, 80]

        # 生成预测
        cls_pred = self.cls_head(features)  # [B, C, 80, 80]
        reg_pred = self.reg_head(features)  # [B, 4, 80, 80]

        # 简化输出
        return {
            'cls': cls_pred,
            'reg': reg_pred,
            'mask': torch.zeros((x.size(0), 1, x.size(2), x.size(3)), device=x.device)
        }


# ============ 3. 简单的损失函数 ============

class SimpleLoss(nn.Module):
    """简化的损失函数"""

    def __init__(self):
        super().__init__()
        self.cls_loss = nn.CrossEntropyLoss()

    def forward(self, predictions, targets):
        """
        简化的损失计算

        Args:
            predictions: 模型输出
            targets: 目标数据，包含 'boxes' 和 'labels'
        """
        device = predictions['cls'].device

        # 分类损失
        B, C, H, W = predictions['cls'].shape

        # 重塑为 [B*H*W, C]
        cls_pred = predictions['cls'].permute(0, 2, 3, 1).reshape(-1, C)

        # 创建简单的目标标签
        # 这里简化处理：如果有边界框，标记为类别1；否则为0
        if targets['boxes'].numel() > 0:
            # 有目标的情况
            cls_target = torch.ones(B * H * W, dtype=torch.long, device=device)
        else:
            # 没有目标的情况
            cls_target = torch.zeros(B * H * W, dtype=torch.long, device=device)

        loss_cls = self.cls_loss(cls_pred, cls_target)

        # 回归损失（简化）
        if targets['boxes'].numel() > 0:
            # 如果有边界框，计算简单的L1损失
            reg_pred = predictions['reg']  # [B, 4, H, W]

            # 简化：只取第一个目标的第一个位置
            reg_pred_simple = reg_pred[0, :, 0, 0]  # [4]
            reg_target = targets['boxes'][0] / 320.0  # 归一化

            loss_reg = nn.functional.l1_loss(reg_pred_simple, reg_target)
        else:
            loss_reg = torch.tensor(0.0, device=device)

        # 总损失
        total_loss = loss_cls + 0.1 * loss_reg

        return total_loss


# ============ 4. 安全的数据加载 ============

from safe_dataset import SafeCatenaryDataset, safe_collate_fn


def create_simple_dataloader(config_path, batch_size=2, img_size=320):
    """创建简单的数据加载器"""

    # 加载配置
    with open(config_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)

    # 解析路径
    dataset_root = Path(config['path'])
    if not dataset_root.is_absolute():
        dataset_root = project_root / dataset_root

    # 创建训练数据集
    train_images_dir = dataset_root / config['train']
    train_dataset = SafeCatenaryDataset(train_images_dir, img_size=img_size)

    # 创建验证数据集
    val_images_dir = dataset_root / config['val']
    val_dataset = SafeCatenaryDataset(val_images_dir, img_size=img_size)

    # 创建数据加载器
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=0,  # 简化：不使用多进程
        collate_fn=safe_collate_fn,
        pin_memory=True
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=0,
        collate_fn=safe_collate_fn,
        pin_memory=True
    )

    print(f"训练集: {len(train_dataset)} 张图像")
    print(f"验证集: {len(val_dataset)} 张图像")

    return train_loader, val_loader


# ============ 5. 简单的训练循环 ============

def train_simple_model(args):
    """训练简化模型"""

    print("\n" + "=" * 60)
    print("训练配置")
    print("=" * 60)
    print(f"设备: {args.device}")
    print(f"图像尺寸: {args.img_size}")
    print(f"批次大小: {args.batch_size}")
    print(f"学习率: {args.lr}")
    print(f"训练轮数: {args.epochs}")
    print("=" * 60)

    # 设置设备
    device = torch.device(args.device)

    # 创建数据加载器
    print("\n创建数据加载器...")
    train_loader, val_loader = create_simple_dataloader(
        args.data_config,
        batch_size=args.batch_size,
        img_size=args.img_size
    )

    # 创建模型
    print("\n创建模型...")
    model = SimpleDetector(num_classes=args.num_classes).to(device)

    # 计算参数数量
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"模型参数: {total_params:,} (可训练: {trainable_params:,})")

    # 创建损失函数和优化器
    criterion = SimpleLoss()
    optimizer = optim.Adam(model.parameters(), lr=args.lr)

    # 训练循环
    print("\n开始训练...")
    print("=" * 60)

    for epoch in range(args.epochs):
        model.train()
        epoch_loss = 0

        print(f"\nEpoch {epoch + 1}/{args.epochs}")
        print("-" * 40)

        for batch_idx, (images, targets) in enumerate(train_loader):
            # 移动到设备
            images = images.to(device)

            # 处理目标 - 确保在正确的设备上
            device_targets = []
            for target in targets:
                device_target = {}
                for key, value in target.items():
                    if isinstance(value, torch.Tensor):
                        device_target[key] = value.to(device)
                    else:
                        device_target[key] = value
                device_targets.append(device_target)

            # 前向传播
            predictions = model(images)

            # 计算损失 - 简化：只使用第一个目标
            loss = criterion(predictions, device_targets[0])

            # 反向传播
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            epoch_loss += loss.item()

            # 打印进度
            if (batch_idx + 1) % args.print_freq == 0:
                avg_loss = epoch_loss / (batch_idx + 1)
                print(f"  Batch {batch_idx + 1}/{len(train_loader)} | Loss: {avg_loss:.4f}")

        # 验证
        model.eval()
        val_loss = 0

        with torch.no_grad():
            for images, targets in val_loader:
                images = images.to(device)

                # 处理目标
                device_targets = []
                for target in targets:
                    device_target = {}
                    for key, value in target.items():
                        if isinstance(value, torch.Tensor):
                            device_target[key] = value.to(device)
                        else:
                            device_target[key] = value
                    device_targets.append(device_target)

                predictions = model(images)
                loss = criterion(predictions, device_targets[0])
                val_loss += loss.item()

        avg_train_loss = epoch_loss / len(train_loader)
        avg_val_loss = val_loss / len(val_loader)

        print(f"\nEpoch {epoch + 1} 结果:")
        print(f"  训练损失: {avg_train_loss:.4f}")
        print(f"  验证损失: {avg_val_loss:.4f}")
        print("=" * 60)

    # 保存模型
    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)

    model_path = save_dir / "simple_model.pth"
    torch.save({
        'epoch': args.epochs,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'args': vars(args)
    }, model_path)

    print(f"\n✅ 训练完成!")
    print(f"模型保存到: {model_path}")

    return model


# ============ 6. 参数配置 ============

class SimpleArgs:
    """简化的参数配置"""

    def __init__(self):
        self.data_config = "data/catenary_simple.yaml"
        self.num_classes = 2
        self.img_size = 320  # 小尺寸，加快训练
        self.epochs = 5  # 少量epoch
        self.batch_size = 2  # 小批次
        self.lr = 0.001
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.print_freq = 1  # 每个批次都打印
        self.save_dir = "./runs/simple"


# ============ 7. 主程序 ============

def main():
    """主程序"""

    # 检查数据集
    dataset_check_path = Path("datasets/catenary_simple")
    if not dataset_check_path.exists():
        print("⚠️ 数据集不存在，正在创建...")
        from check_dataset import create_minimal_dataset
        create_minimal_dataset(project_root)

    # 检查配置文件
    config_check_path = Path("data/catenary_simple.yaml")
    if not config_check_path.exists():
        print("⚠️ 配置文件不存在，正在创建...")
        from check_dataset import create_config_file
        create_config_file(project_root)

    # 创建参数
    args = SimpleArgs()

    try:
        # 训练模型
        model = train_simple_model(args)

        print("\n" + "=" * 60)
        print("测试模型推理...")
        print("=" * 60)

        # 测试推理
        model.eval()
        test_input = torch.randn(1, 3, args.img_size, args.img_size).to(args.device)
        with torch.no_grad():
            output = model(test_input)

        print(f"模型输出:")
        for key, value in output.items():
            print(f"  {key}: {value.shape}")

        print("\n✅ 简化训练成功完成!")
        print("\n下一步:")
        print("1. 检查 runs/simple/simple_model.pth")
        print("2. 如果成功，可以尝试增加训练轮数")
        print("3. 逐步增加模型复杂度")

    except Exception as e:
        print(f"\n❌ 训练失败: {e}")
        import traceback
        traceback.print_exc()

        print("\n" + "=" * 60)
        print("故障排除:")
        print("1. 检查数据集: python check_dataset.py")
        print("2. 测试数据加载: python safe_dataset.py")
        print("3. 确保PyTorch正确安装")
        print("=" * 60)


if __name__ == "__main__":
    main()