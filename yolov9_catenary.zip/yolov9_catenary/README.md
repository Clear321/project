# YOLOv9接触网异物检测项目

## 项目简介
基于YOLOv9的自适应可变形卷积与焦点感知接触网异物检测系统

## 项目结构
yolov9_catenary/
├── data/ # 数据集配置文件
├── datasets/ # 数据集目录
├── models/ # 模型定义
├── utils/ # 工具函数（包含dataset_tools.py）
├── scripts/ # 实用脚本
├── runs/ # 训练结果
├── logs/ # 训练日志
├── results/ # 检测结果
├── evaluation/ # 评估结果
├── train.py # 训练脚本
├── detect.py # 检测脚本
├── evaluate.py # 评估脚本
├── requirements.txt # 依赖包
└── README.md # 项目说明