import argparse
import os
import torch
import cv2
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
from pathlib import Path
import sys

sys.path.append(str(Path(__file__).parent))

from models.yolo import YOLOv9_Catenary


class CatenaryDetector:
    """接触网异物检测器"""

    def __init__(self, model_path, device='cuda', conf_threshold=0.5, iou_threshold=0.5):
        self.device = torch.device(device if torch.cuda.is_available() else 'cpu')
        self.conf_threshold = conf_threshold
        self.iou_threshold = iou_threshold

        # 加载模型
        self.model = self.load_model(model_path)
        self.model.eval()

    def load_model(self, model_path):
        """加载训练好的模型"""
        checkpoint = torch.load(model_path, map_location=self.device)
        args = checkpoint['args']

        model = YOLOv9_Catenary(nc=args.num_classes).to(self.device)
        model.load_state_dict(checkpoint['model_state_dict'])

        return model

    def preprocess(self, image):
        """图像预处理"""
        # 转换为RGB
        if len(image.shape) == 2:
            image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
        elif image.shape[2] == 4:
            image = cv2.cvtColor(image, cv2.COLOR_BGRA2RGB)
        else:
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        # 调整大小
        orig_h, orig_w = image.shape[:2]
        image_resized = cv2.resize(image, (640, 640))

        # 归一化
        image_tensor = torch.from_numpy(image_resized).permute(2, 0, 1).float() / 255.0
        image_tensor = image_tensor.unsqueeze(0).to(self.device)

        return image_tensor, (orig_h, orig_w)

    def postprocess(self, predictions, orig_size):
        """后处理预测结果"""
        orig_h, orig_w = orig_size

        # 获取预测结果
        cls_pred = predictions['cls'][0]  # (nc, H, W)
        reg_pred = predictions['reg'][0]  # (4, H, W)
        mask_pred = predictions['mask'][0]  # (1, H, W)
        conf_pred = predictions['conf'][0]  # (1, H, W)

        # 应用阈值
        conf_mask = conf_pred > self.conf_threshold

        if not conf_mask.any():
            return [], None

        # 获取高置信度位置
        conf_indices = torch.where(conf_mask)

        detections = []
        for idx in range(len(conf_indices[0])):
            h_idx, w_idx = conf_indices[1][idx].item(), conf_indices[2][idx].item()

            # 获取边界框
            bbox = reg_pred[:, h_idx, w_idx].cpu().numpy()

            # 反归一化到原始尺寸
            x_center = bbox[0] * orig_w
            y_center = bbox[1] * orig_h
            width = bbox[2] * orig_w
            height = bbox[3] * orig_h

            x1 = x_center - width / 2
            y1 = y_center - height / 2
            x2 = x_center + width / 2
            y2 = y_center + height / 2

            # 获取置信度
            confidence = conf_pred[0, h_idx, w_idx].item()

            # 获取类别
            class_scores = cls_pred[:, h_idx, w_idx]
            class_id = torch.argmax(class_scores).item()
            class_score = class_scores[class_id].item()

            # 获取掩码（调整到原始尺寸）
            mask = mask_pred[0, h_idx, w_idx].cpu().numpy()

            detections.append({
                'bbox': [x1, y1, x2, y2],
                'confidence': confidence,
                'class_id': class_id,
                'class_score': class_score,
                'mask': mask
            })

        # NMS
        if detections:
            detections = self.non_max_suppression(detections)

        return detections

    def non_max_suppression(self, detections):
        """非极大值抑制"""
        if not detections:
            return []

        # 按置信度排序
        detections = sorted(detections, key=lambda x: x['confidence'], reverse=True)

        keep = []
        while detections:
            # 取最高置信度的检测
            best = detections.pop(0)
            keep.append(best)

            # 计算与剩余检测的IoU
            to_remove = []
            for i, det in enumerate(detections):
                iou = self.calculate_iou(best['bbox'], det['bbox'])
                if iou > self.iou_threshold:
                    to_remove.append(i)

            # 移除重叠的检测
            for idx in reversed(to_remove):
                detections.pop(idx)

        return keep

    def calculate_iou(self, box1, box2):
        """计算IoU"""
        x1 = max(box1[0], box2[0])
        y1 = max(box1[1], box2[1])
        x2 = min(box1[2], box2[2])
        y2 = min(box1[3], box2[3])

        if x2 < x1 or y2 < y1:
            return 0.0

        intersection = (x2 - x1) * (y2 - y1)
        area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
        area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
        union = area1 + area2 - intersection

        return intersection / union if union > 0 else 0

    def detect(self, image_path):
        """检测图像中的异物"""
        # 读取图像
        if isinstance(image_path, str):
            image = cv2.imread(image_path)
        else:
            image = image_path

        # 预处理
        image_tensor, orig_size = self.preprocess(image)

        # 推理
        with torch.no_grad():
            predictions = self.model(image_tensor)

        # 后处理
        detections = self.postprocess(predictions, orig_size)

        return detections, image

    def visualize(self, image, detections, save_path=None):
        """可视化检测结果"""
        # 复制图像
        vis_image = image.copy()

        for det in detections:
            bbox = det['bbox']
            confidence = det['confidence']
            class_id = det['class_id']

            # 绘制边界框
            x1, y1, x2, y2 = map(int, bbox)
            cv2.rectangle(vis_image, (x1, y1), (x2, y2), (0, 255, 0), 2)

            # 绘制标签
            label = f"Foreign Object: {confidence:.2f}"
            cv2.putText(vis_image, label, (x1, y1 - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

            # 绘制掩码（如果有）
            if 'mask' in det and det['mask'] is not None:
                # 创建掩码图像
                mask = np.zeros_like(vis_image[:, :, 0])
                mask[y1:y2, x1:x2] = det['mask'] * 255

                # 将掩码叠加到图像上
                colored_mask = np.zeros_like(vis_image)
                colored_mask[:, :, 1] = mask  # 绿色掩码

                vis_image = cv2.addWeighted(vis_image, 1.0, colored_mask, 0.3, 0)

        if save_path:
            cv2.imwrite(save_path, cv2.cvtColor(vis_image, cv2.COLOR_RGB2BGR))

        return vis_image


def main():
    parser = argparse.ArgumentParser(description='Detect foreign objects in catenary images')
    parser.add_argument('--model-path', type=str, required=True, help='Path to trained model')
    parser.add_argument('--input', type=str, required=True, help='Input image or directory')
    parser.add_argument('--output', type=str, default='./results', help='Output directory')
    parser.add_argument('--conf-threshold', type=float, default=0.5, help='Confidence threshold')
    parser.add_argument('--iou-threshold', type=float, default=0.5, help='IoU threshold for NMS')

    args = parser.parse_args()

    # 创建检测器
    detector = CatenaryDetector(
        model_path=args.model_path,
        conf_threshold=args.conf_threshold,
        iou_threshold=args.iou_threshold
    )

    # 创建输出目录
    os.makedirs(args.output, exist_ok=True)

    # 处理输入
    input_path = Path(args.input)

    if input_path.is_file():
        # 单张图像
        detections, image = detector.detect(str(input_path))
        vis_image = detector.visualize(image, detections)

        # 保存结果
        output_path = Path(args.output) / f'result_{input_path.name}'
        cv2.imwrite(str(output_path), cv2.cvtColor(vis_image, cv2.COLOR_RGB2BGR))

        print(f"Detection completed. Results saved to {output_path}")

    elif input_path.is_dir():
        # 图像目录
        image_files = list(input_path.glob('*.jpg')) + list(input_path.glob('*.png'))

        for img_file in image_files:
            print(f"Processing {img_file.name}...")

            detections, image = detector.detect(str(img_file))
            vis_image = detector.visualize(image, detections)

            # 保存结果
            output_path = Path(args.output) / f'result_{img_file.name}'
            cv2.imwrite(str(output_path), cv2.cvtColor(vis_image, cv2.COLOR_RGB2BGR))

        print(f"Processed {len(image_files)} images. Results saved to {args.output}")

    else:
        print(f"Input path {args.input} does not exist")
        return


if __name__ == '__main__':
    main()