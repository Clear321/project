# create_test_data.py
"""
创建测试数据集，避免路径问题
"""
import os
import cv2
import numpy as np
from pathlib import Path
import random


def create_test_dataset():
    """创建测试数据集"""
    base_dir = Path("datasets/catenary_minimal")

    # 创建目录结构
    splits = ['train', 'val', 'test']
    for split in splits:
        (base_dir / split / 'images').mkdir(parents=True, exist_ok=True)
        (base_dir / split / 'labels').mkdir(parents=True, exist_ok=True)

    print(f"创建测试数据集在: {base_dir.absolute()}")

    # 创建一些测试图像
    for split in splits:
        num_images = 5 if split == 'train' else 2  # 训练5张，验证测试各2张

        for i in range(num_images):
            # 创建简单图像
            img = np.ones((640, 640, 3), dtype=np.uint8) * 135  # 天蓝色背景

            # 添加电线
            cv2.line(img, (100, 320), (540, 320), (50, 50, 50), 3)

            # 随机添加异物（50%的概率）
            if random.random() > 0.5:
                x = random.randint(200, 400)
                y = random.randint(200, 400)
                w = random.randint(50, 100)
                h = random.randint(50, 100)

                # 绘制异物（红色矩形）
                cv2.rectangle(img, (x, y), (x + w, y + h), (0, 0, 255), -1)

                # 创建标签（YOLO格式）
                x_center = (x + w / 2) / 640
                y_center = (y + h / 2) / 640
                width = w / 640
                height = h / 640

                label = f"1 {x_center:.6f} {y_center:.6f} {width:.6f} {height:.6f}"
            else:
                label = ""  # 无物体

            # 保存图像
            img_path = base_dir / split / 'images' / f'img_{i:03d}.jpg'
            cv2.imwrite(str(img_path), img)

            # 保存标签
            label_path = base_dir / split / 'labels' / f'img_{i:03d}.txt'
            with open(label_path, 'w', encoding='utf-8') as f:
                f.write(label)

            print(f"创建: {img_path}")

    # 创建数据集配置文件
    config_content = """# 最小测试数据集配置
path: ./datasets/catenary_minimal
train: train/images
val: val/images
test: test/images

# 类别数
nc: 2

# 类别名称
names: ['background', 'foreign_object']
"""

    config_dir = Path("data")
    config_dir.mkdir(exist_ok=True)

    config_path = config_dir / "catenary_minimal.yaml"
    with open(config_path, 'w', encoding='utf-8') as f:
        f.write(config_content)

    print(f"\n创建数据集配置文件: {config_path}")

    # 验证数据集
    print("\n验证数据集结构:")
    for split in splits:
        images_dir = base_dir / split / 'images'
        labels_dir = base_dir / split / 'labels'

        images = list(images_dir.glob('*.jpg'))
        labels = list(labels_dir.glob('*.txt'))

        print(f"{split}: {len(images)} 张图像, {len(labels)} 个标签文件")

    return base_dir


if __name__ == "__main__":
    print("=" * 60)
    print("创建最小测试数据集")
    print("=" * 60)

    dataset_dir = create_test_dataset()

    print("\n" + "=" * 60)
    print("数据集创建完成！")
    print(f"路径: {dataset_dir.absolute()}")
    print("\n使用方法:")
    print(f"python train.py --data-config data/catenary_minimal.yaml --epochs 10")
    print("=" * 60)