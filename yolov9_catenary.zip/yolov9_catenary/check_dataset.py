# check_dataset.py
"""
检查数据集格式并修复常见问题
"""
import os
import sys
from pathlib import Path
import yaml
import cv2
import numpy as np


def check_dataset_structure():
    """检查数据集结构"""
    print("=" * 60)
    print("检查数据集结构")
    print("=" * 60)

    project_root = Path(__file__).parent

    # 检查配置文件
    config_path = project_root / "data" / "catenary_minimal.yaml"
    if not config_path.exists():
        print("❌ 配置文件不存在")
        create_config_file(project_root)
    else:
        print("✓ 配置文件存在")

        with open(config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)

        print(f"配置文件内容:")
        print(f"  数据集路径: {config.get('path', '未指定')}")
        print(f"  训练集: {config.get('train', '未指定')}")
        print(f"  验证集: {config.get('val', '未指定')}")

    # 检查数据集目录
    dataset_path = project_root / "datasets" / "catenary_minimal"
    if not dataset_path.exists():
        print("\n❌ 数据集目录不存在")
        create_minimal_dataset(project_root)
    else:
        print(f"\n✓ 数据集目录存在: {dataset_path}")

        # 检查子目录
        for split in ['train', 'val', 'test']:
            images_dir = dataset_path / split / 'images'
            labels_dir = dataset_path / split / 'labels'

            if images_dir.exists():
                images = list(images_dir.glob('*.jpg')) + list(images_dir.glob('*.png'))
                print(f"  {split}/images: {len(images)} 张图像")
            else:
                print(f"  ❌ {split}/images: 目录不存在")

            if labels_dir.exists():
                labels = list(labels_dir.glob('*.txt'))
                print(f"  {split}/labels: {len(labels)} 个标签文件")
            else:
                print(f"  ❌ {split}/labels: 目录不存在")

    return True


def check_dataset_format():
    """检查数据集格式"""
    print("\n" + "=" * 60)
    print("检查数据集格式")
    print("=" * 60)

    project_root = Path(__file__).parent
    dataset_path = project_root / "datasets" / "catenary_minimal"

    issues_found = []

    for split in ['train', 'val']:
        images_dir = dataset_path / split / 'images'
        labels_dir = dataset_path / split / 'labels'

        if not images_dir.exists() or not labels_dir.exists():
            continue

        # 检查图像文件
        images = sorted(list(images_dir.glob('*.jpg')) + list(images_dir.glob('*.png')))

        for img_file in images[:3]:  # 只检查前3个
            # 检查图像
            try:
                img = cv2.imread(str(img_file))
                if img is None:
                    issues_found.append(f"{img_file}: 无法读取图像")
                    continue

                h, w = img.shape[:2]
                print(f"  {img_file.name}: {w}x{h} 像素")

            except Exception as e:
                issues_found.append(f"{img_file}: 图像错误 - {e}")

            # 检查对应的标签文件
            label_file = labels_dir / f"{img_file.stem}.txt"
            if not label_file.exists():
                print(f"  ⚠️  {img_file.name}: 没有对应的标签文件")
                continue

            try:
                with open(label_file, 'r', encoding='utf-8') as f:
                    lines = f.readlines()

                print(f"  {label_file.name}: {len(lines)} 个目标")

                for i, line in enumerate(lines):
                    parts = line.strip().split()
                    if len(parts) >= 5:
                        class_id = int(parts[0])
                        x_center = float(parts[1])
                        y_center = float(parts[2])
                        width = float(parts[3])
                        height = float(parts[4])

                        # 检查值是否在有效范围内
                        if not (0 <= x_center <= 1 and 0 <= y_center <= 1 and
                                0 <= width <= 1 and 0 <= height <= 1):
                            issues_found.append(f"{label_file}: 第{i + 1}行值超出范围")

                    else:
                        issues_found.append(f"{label_file}: 第{i + 1}行格式错误")

            except Exception as e:
                issues_found.append(f"{label_file}: 读取错误 - {e}")

    # 报告问题
    if issues_found:
        print(f"\n⚠️ 发现 {len(issues_found)} 个问题:")
        for issue in issues_found[:5]:  # 只显示前5个问题
            print(f"  • {issue}")
        if len(issues_found) > 5:
            print(f"  ... 还有 {len(issues_found) - 5} 个问题")
    else:
        print("\n✓ 数据集格式检查通过")

    return len(issues_found) == 0


def create_config_file(project_root):
    """创建配置文件"""
    print("创建配置文件...")

    config_dir = project_root / "data"
    config_dir.mkdir(exist_ok=True)

    config_content = """# 接触网异物检测数据集配置
# 使用绝对路径避免问题
path: ./datasets/catenary_simple
train: train/images
val: val/images
test: test/images

# 类别数
nc: 2

# 类别名称
names: ['background', 'foreign_object']
"""

    config_path = config_dir / "catenary_simple.yaml"
    with open(config_path, 'w', encoding='utf-8') as f:
        f.write(config_content)

    print(f"✓ 创建配置文件: {config_path}")
    return config_path


def create_minimal_dataset(project_root):
    """创建最小数据集"""
    print("创建最小数据集...")

    import cv2
    import numpy as np
    import random

    dataset_path = project_root / "datasets" / "catenary_simple"

    # 创建目录
    for split in ['train', 'val', 'test']:
        (dataset_path / split / 'images').mkdir(parents=True, exist_ok=True)
        (dataset_path / split / 'labels').mkdir(parents=True, exist_ok=True)

    print(f"创建数据集目录: {dataset_path}")

    # 创建简单的测试图像
    for split in ['train', 'val']:
        num_images = 10 if split == 'train' else 5

        for i in range(num_images):
            # 创建简单图像 (320x320 小尺寸)
            img = np.ones((320, 320, 3), dtype=np.uint8) * 135  # 天蓝色

            # 添加简单的电线
            cv2.line(img, (50, 160), (270, 160), (50, 50, 50), 2)

            # 50%的概率添加异物
            has_object = random.random() > 0.5

            if has_object:
                # 创建简单的矩形异物
                x = random.randint(100, 220)
                y = random.randint(100, 220)
                w = random.randint(30, 60)
                h = random.randint(30, 60)

                # 红色矩形
                cv2.rectangle(img, (x, y), (x + w, y + h), (0, 0, 255), -1)

                # 计算YOLO格式坐标
                x_center = (x + w / 2) / 320
                y_center = (y + h / 2) / 320
                width = w / 320
                height = h / 320

                # 创建标签
                label = f"1 {x_center:.6f} {y_center:.6f} {width:.6f} {height:.6f}"
            else:
                label = ""  # 没有物体

            # 保存图像
            img_path = dataset_path / split / 'images' / f'image_{i:03d}.jpg'
            cv2.imwrite(str(img_path), img)

            # 保存标签
            label_path = dataset_path / split / 'labels' / f'image_{i:03d}.txt'
            with open(label_path, 'w', encoding='utf-8') as f:
                f.write(label)

            print(f"  创建: {img_path.name}")

    print(f"✓ 创建最小数据集完成")
    return dataset_path


def fix_dataset_issues():
    """修复数据集问题"""
    print("\n" + "=" * 60)
    print("自动修复数据集问题")
    print("=" * 60)

    project_root = Path(__file__).parent

    # 1. 确保配置文件存在
    config_file = create_config_file(project_root)

    # 2. 确保数据集存在
    dataset_path = project_root / "datasets" / "catenary_simple"
    if not dataset_path.exists():
        create_minimal_dataset(project_root)

    # 3. 验证修复
    check_dataset_structure()
    format_ok = check_dataset_format()

    if format_ok:
        print("\n✅ 数据集修复完成！")
        print(f"配置文件: {config_file}")
        print(f"数据集: {dataset_path}")
        print(f"\n使用命令: python train_simple.py")
    else:
        print("\n⚠️ 数据集仍有问题，建议手动检查")

    return format_ok


if __name__ == "__main__":
    # 检查当前数据集
    print("1. 检查当前数据集状态...")
    check_dataset_structure()
    check_dataset_format()

    print("\n" + "=" * 60)
    print("2. 建议修复选项:")
    print("   A: 自动修复数据集")
    print("   B: 手动检查")
    print("=" * 60)

    choice = input("\n选择 (A/B): ").strip().upper()

    if choice == 'A':
        fix_dataset_issues()
    else:
        print("\n请手动检查以下文件:")
        print("1. 检查 data/catenary_minimal.yaml 文件")
        print("2. 检查 datasets/catenary_minimal/ 目录结构")
        print("3. 确保所有标签文件都是有效的YOLO格式")