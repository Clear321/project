# fix_dataset_structure.py
"""
一键修复数据集结构
"""
import os
import sys
from pathlib import Path
import cv2
import numpy as np
import random
import yaml


def create_complete_dataset_structure():
    """创建完整的数据集结构"""
    print("=" * 60)
    print("创建完整数据集结构")
    print("=" * 60)

    # 项目根目录
    project_root = Path(__file__).parent

    # 数据集根目录
    dataset_root = project_root / "datasets" / "catenary_simple"

    print(f"数据集路径: {dataset_root.absolute()}")

    # 1. 创建所有必要的目录
    print("\n1. 创建目录结构...")

    directories = [
        "train/images",
        "train/labels",
        "val/images",
        "val/labels",
        "test/images",
        "test/labels",
    ]

    for dir_path in directories:
        full_path = dataset_root / dir_path
        full_path.mkdir(parents=True, exist_ok=True)
        print(f"  ✓ 创建: {dir_path}")

    # 2. 创建配置文件
    print("\n2. 创建配置文件...")

    config_dir = project_root / "data"
    config_dir.mkdir(exist_ok=True)

    # 使用绝对路径避免问题
    abs_dataset_path = dataset_root.absolute()

    config_content = f"""# 接触网异物检测数据集配置
path: {abs_dataset_path}
train: train/images
val: val/images
test: test/images

# 类别数
nc: 2

# 类别名称
names: ['background', 'foreign_object']
"""

    config_path = config_dir / "catenary_simple.yaml"
    with open(config_path, 'w', encoding='utf-8') as f:
        f.write(config_content)

    print(f"  ✓ 创建配置文件: {config_path}")

    # 3. 创建测试图像和标签
    print("\n3. 创建测试图像和标签...")

    # 图像尺寸
    img_width, img_height = 320, 320

    # 训练集 (10张图像)
    print("  创建训练集...")
    for i in range(10):
        create_sample_image_and_label(
            dataset_root / "train" / "images",
            dataset_root / "train" / "labels",
            i, img_width, img_height, split="train"
        )

    # 验证集 (5张图像)
    print("  创建验证集...")
    for i in range(5):
        create_sample_image_and_label(
            dataset_root / "val" / "images",
            dataset_root / "val" / "labels",
            i, img_width, img_height, split="val"
        )

    # 测试集 (3张图像)
    print("  创建测试集...")
    for i in range(3):
        create_sample_image_and_label(
            dataset_root / "test" / "images",
            dataset_root / "test" / "labels",
            i, img_width, img_height, split="test"
        )

    # 4. 验证数据集
    print("\n4. 验证数据集结构...")
    verify_dataset_structure(dataset_root)

    # 5. 创建验证脚本
    print("\n5. 创建验证脚本...")
    create_verification_script(project_root)

    print("\n" + "=" * 60)
    print("数据集创建完成!")
    print("=" * 60)

    print(f"\n数据集路径: {dataset_root}")
    print(f"配置文件: {config_path}")

    print("\n验证命令:")
    print(f"python verify_dataset.py")
    print(f"\n训练命令:")
    print(f"python train_simple.py")

    return True


def create_sample_image_and_label(images_dir, labels_dir, idx, width, height, split="train"):
    """创建样本图像和标签"""

    # 创建图像文件名
    img_filename = f"image_{idx:03d}.jpg"
    img_path = images_dir / img_filename

    # 创建标签文件名
    label_filename = f"image_{idx:03d}.txt"
    label_path = labels_dir / label_filename

    # 创建图像 (天蓝色背景)
    img = np.ones((height, width, 3), dtype=np.uint8) * np.array([135, 206, 235], dtype=np.uint8)

    # 添加电线 (灰色)
    wire_y = height // 2
    cv2.line(img, (50, wire_y), (width - 50, wire_y), (50, 50, 50), 2)

    # 添加电线杆
    pole_x = width // 2
    pole_top = wire_y - 100
    pole_bottom = height - 50
    cv2.rectangle(img, (pole_x - 10, pole_top), (pole_x + 10, pole_bottom), (80, 80, 80), -1)

    # 随机决定是否添加异物
    has_object = random.random() > 0.3  # 70%的概率有异物

    if has_object:
        # 创建异物 (红色矩形)
        obj_width = random.randint(30, 80)
        obj_height = random.randint(30, 80)
        obj_x = random.randint(50, width - obj_width - 50)
        obj_y = random.randint(50, height - obj_height - 50)

        # 绘制异物
        cv2.rectangle(img, (obj_x, obj_y), (obj_x + obj_width, obj_y + obj_height), (0, 0, 255), -1)

        # 添加一些纹理
        for _ in range(random.randint(3, 8)):
            tx = random.randint(obj_x, obj_x + obj_width)
            ty = random.randint(obj_y, obj_y + obj_height)
            cv2.circle(img, (tx, ty), random.randint(2, 4), (0, 0, 200), -1)

        # 计算YOLO格式坐标 (归一化)
        x_center = (obj_x + obj_width / 2) / width
        y_center = (obj_y + obj_height / 2) / height
        obj_width_norm = obj_width / width
        obj_height_norm = obj_height / height

        # 创建标签内容
        label_content = f"1 {x_center:.6f} {y_center:.6f} {obj_width_norm:.6f} {obj_height_norm:.6f}"
    else:
        # 没有异物
        label_content = ""

    # 保存图像
    cv2.imwrite(str(img_path), img)

    # 保存标签
    with open(label_path, 'w', encoding='utf-8') as f:
        f.write(label_content)

    print(f"    创建: {split}/{img_filename} {'(有异物)' if has_object else '(无异物)'}")

    return img_path, label_path


def verify_dataset_structure(dataset_root):
    """验证数据集结构"""

    print("  检查目录结构...")

    expected_dirs = [
        "train/images",
        "train/labels",
        "val/images",
        "val/labels",
        "test/images",
        "test/labels",
    ]

    all_ok = True
    for dir_path in expected_dirs:
        full_path = dataset_root / dir_path
        if full_path.exists():
            # 统计文件数量
            if "images" in dir_path:
                files = list(full_path.glob("*.jpg")) + list(full_path.glob("*.png"))
            else:
                files = list(full_path.glob("*.txt"))

            print(f"    ✓ {dir_path}: {len(files)} 个文件")
        else:
            print(f"    ✗ {dir_path}: 目录不存在")
            all_ok = False

    # 检查文件对应关系
    print("\n  检查文件对应关系...")

    for split in ["train", "val", "test"]:
        images_dir = dataset_root / split / "images"
        labels_dir = dataset_root / split / "labels"

        if images_dir.exists() and labels_dir.exists():
            images = sorted([f.stem for f in images_dir.glob("*.jpg")])
            labels = sorted([f.stem for f in labels_dir.glob("*.txt")])

            # 检查是否有对应的标签文件
            missing_labels = []
            for img_name in images:
                if img_name not in labels:
                    missing_labels.append(img_name)

            if missing_labels:
                print(f"    ⚠️ {split}: {len(missing_labels)} 张图像没有对应的标签")
            else:
                print(f"    ✓ {split}: 所有图像都有对应的标签")

    return all_ok


def create_verification_script(project_root):
    """创建验证脚本"""

    script_content = '''"""
验证数据集结构
"""
import os
import sys
from pathlib import Path
import cv2
import numpy as np

def verify_dataset():
    """验证数据集"""
    print("=" * 60)
    print("验证数据集结构")
    print("=" * 60)

    # 项目根目录
    project_root = Path(__file__).parent

    # 数据集路径
    dataset_path = project_root / "datasets" / "catenary_simple"

    if not dataset_path.exists():
        print("❌ 数据集目录不存在!")
        return False

    print(f"数据集路径: {dataset_path}")

    # 检查目录结构
    required_dirs = [
        "train/images",
        "train/labels",
        "val/images",
        "val/labels",
        "test/images", 
        "test/labels",
    ]

    print("\n1. 检查目录结构:")
    for dir_name in required_dirs:
        dir_path = dataset_path / dir_name
        if dir_path.exists():
            # 统计文件
            if "images" in dir_name:
                files = list(dir_path.glob("*.jpg")) + list(dir_path.glob("*.png"))
                file_type = "图像"
            else:
                files = list(dir_path.glob("*.txt"))
                file_type = "标签"

            print(f"   ✓ {dir_name}: {len(files)} 个{file_type}文件")
        else:
            print(f"   ✗ {dir_name}: 目录不存在")
            return False

    # 检查样本文件
    print("\n2. 检查样本文件:")

    for split in ["train", "val"]:
        images_dir = dataset_path / split / "images"
        labels_dir = dataset_path / split / "labels"

        # 获取第一个图像文件
        image_files = list(images_dir.glob("*.jpg"))
        if image_files:
            img_path = image_files[0]

            # 读取图像
            img = cv2.imread(str(img_path))
            if img is None:
                print(f"   ✗ {split}: 无法读取图像 {img_path.name}")
                continue

            h, w = img.shape[:2]
            print(f"   ✓ {split}/images: {img_path.name} ({w}x{h})")

            # 检查对应的标签
            label_path = labels_dir / f"{img_path.stem}.txt"
            if label_path.exists():
                with open(label_path, 'r') as f:
                    content = f.read().strip()

                if content:
                    print(f"   ✓ {split}/labels: {label_path.name} (有目标)")
                else:
                    print(f"   ✓ {split}/labels: {label_path.name} (无目标)")
            else:
                print(f"   ⚠️ {split}/labels: 没有对应的标签文件")

    print("\n" + "=" * 60)
    print("数据集验证完成!")
    print("=" * 60)

    return True

if __name__ == "__main__":
    success = verify_dataset()

    if success:
        print("\n✅ 数据集结构正确，可以开始训练!")
        print("\n运行训练命令:")
        print("  python train_simple.py")
    else:
        print("\n❌ 数据集有问题，请运行修复脚本:")
        print("  python fix_dataset_structure.py")
'''

    script_path = project_root / "verify_dataset.py"
    with open(script_path, 'w', encoding='utf-8') as f:
        f.write(script_content)

    print(f"  ✓ 创建验证脚本: {script_path}")

    return script_path


def main():
    """主函数"""

    print("\n开始修复数据集结构...")

    try:
        success = create_complete_dataset_structure()

        if success:
            print("\n✅ 数据集修复成功!")
            print("\n下一步:")
            print("1. 运行验证脚本: python verify_dataset.py")
            print("2. 运行训练脚本: python train_simple.py")
        else:
            print("\n❌ 数据集修复失败")

    except Exception as e:
        print(f"\n❌ 修复过程中出错: {e}")
        import traceback
        traceback.print_exc()

        print("\n手动创建数据集:")
        print("1. 创建目录: datasets/catenary_simple/train/images/")
        print("2. 创建目录: datasets/catenary_simple/train/labels/")
        print("3. 添加一些 .jpg 图像文件到 images/ 目录")
        print("4. 添加对应的 .txt 标签文件到 labels/ 目录")


if __name__ == "__main__":
    main()