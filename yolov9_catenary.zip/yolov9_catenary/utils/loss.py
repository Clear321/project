import torch
import torch.nn as nn
import torch.nn.functional as F

class CatenaryLoss(nn.Module):
    def __init__(self, alpha=0.25, gamma=2.0, lambda_cls=1.0, lambda_reg=1.0, lambda_mask=1.0, lambda_boundary=0.5):
        super().__init__()
        # 存储传入的参数（用于后续计算损失）
        self.alpha = alpha  # Focal Loss 的 alpha
        self.gamma = gamma  # Focal Loss 的 gamma
        self.lambda_cls = lambda_cls  # 分类损失权重
        self.lambda_reg = lambda_reg  # 回归损失权重
        self.lambda_mask = lambda_mask  # 掩码损失权重
        self.lambda_boundary = lambda_boundary  # 边界损失权重
    """接触网异物检测的复合损失函数 - 修复版本"""

    def forward(self, predictions, targets):
        # 关键修复：确保输入格式正确
        device = predictions['cls'].device if hasattr(predictions['cls'], 'device') else 'cpu'

        # 处理目标边界框
        if 'bbox' in targets:
            bbox = targets['bbox']
            # 检查并转换格式
            if isinstance(bbox, (list, tuple)):
                # 如果是空列表
                if len(bbox) == 0:
                    bbox = torch.zeros((0, 4), dtype=torch.float32, device=device)
                else:
                    # 检查是否是嵌套结构
                    if isinstance(bbox[0], (list, tuple)):
                        bbox = torch.tensor(bbox, dtype=torch.float32, device=device)
                    else:
                        # 单一边界框
                        bbox = torch.tensor([bbox], dtype=torch.float32, device=device)

            # 确保是2D tensor [N, 4]
            if bbox.dim() == 1 and bbox.shape[0] == 4:
                bbox = bbox.unsqueeze(0)  # [4] -> [1, 4]

            targets['bbox'] = bbox

        # 处理预测的回归输出
        pred_reg = predictions['reg']
        # 如果预测是4D [B, 4, H, W]，需要重塑
        if pred_reg.dim() == 4:
            B, C, H, W = pred_reg.shape
            # 重塑为 [B*H*W, C]
            pred_reg = pred_reg.permute(0, 2, 3, 1).reshape(-1, C)

        # 计算损失
        cls_loss = self.focal_loss(predictions['cls'], targets['cls'])

        # 只有当有目标时才计算回归损失
        if targets['bbox'].numel() > 0:
            # 确保形状匹配
            if pred_reg.shape[0] != targets['bbox'].shape[0]:
                # 如果预测数量多于目标，只取前N个
                min_len = min(pred_reg.shape[0], targets['bbox'].shape[0])
                pred_reg = pred_reg[:min_len]
                targets['bbox'] = targets['bbox'][:min_len]

            reg_loss = self.regression_loss(pred_reg, targets['bbox'])
        else:
            reg_loss = torch.tensor(0.0, device=device)

        mask_loss = self.mask_loss(predictions['mask'], targets['mask'])

        total_loss = (
                self.lambda_cls * cls_loss +
                self.lambda_reg * reg_loss +
                self.lambda_mask * mask_loss
        )

        return total_loss

    def regression_loss(self, pred, target, giou_loss=None):
        """回归损失：确保输入正确"""
        # 确保pred和target都是tensor
        if not isinstance(pred, torch.Tensor):
            pred = torch.tensor(pred, dtype=torch.float32, device=target.device if hasattr(target, 'device') else 'cpu')

        if not isinstance(target, torch.Tensor):
            target = torch.tensor(target, dtype=torch.float32, device=pred.device)

        # 确保形状匹配
        if pred.shape != target.shape:
            # 尝试广播或调整
            if pred.dim() == 2 and target.dim() == 2:
                if pred.shape[0] != target.shape[0]:
                    # 取最小长度
                    min_len = min(pred.shape[0], target.shape[0])
                    pred = pred[:min_len]
                    target = target[:min_len]

        # 计算GIoU损失
        giou_loss = giou_loss(pred, target)

        # 计算L1损失
        l1_loss = F.l1_loss(pred, target, reduction='mean')

        return giou_loss + 0.05 * l1_loss

    