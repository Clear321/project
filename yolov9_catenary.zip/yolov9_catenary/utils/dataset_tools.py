"""
数据集工具模块
包含：数据创建、增强、转换等功能
"""
import cv2
import numpy as np
import random
from pathlib import Path
import albumentations as A
from PIL import Image
import json
import os
import requests
from io import BytesIO
import time


class DatasetCreator:
    """数据集创建器"""

    @staticmethod
    def create_minimal_dataset(output_dir="./datasets/catenary_minimal", num_images=100):
        """
        创建最小测试数据集

        Args:
            output_dir: 输出目录
            num_images: 图像数量
        """
        print(f"创建最小数据集到 {output_dir}...")
        base_dir = Path(output_dir)

        # 创建目录结构
        splits = ['train', 'val', 'test']
        split_ratios = [0.7, 0.2, 0.1]

        for split in splits:
            (base_dir / split / 'images').mkdir(parents=True, exist_ok=True)
            (base_dir / split / 'labels').mkdir(parents=True, exist_ok=True)

        # 计算各分集数量
        train_count = int(num_images * split_ratios[0])
        val_count = int(num_images * split_ratios[1])
        test_count = num_images - train_count - val_count

        print(f"训练集: {train_count}张, 验证集: {val_count}张, 测试集: {test_count}张")

        img_idx = 0

        # 创建训练集
        for i in range(train_count):
            DatasetCreator._create_single_image(base_dir, 'train', img_idx)
            img_idx += 1

        # 创建验证集
        for i in range(val_count):
            DatasetCreator._create_single_image(base_dir, 'val', img_idx)
            img_idx += 1

        # 创建测试集
        for i in range(test_count):
            DatasetCreator._create_single_image(base_dir, 'test', img_idx)
            img_idx += 1

        print(f"✓ 成功创建 {num_images} 张图像")

        # 创建数据集配置文件
        config_content = f"""# 最小测试数据集配置
path: {output_dir}
train: train/images
val: val/images
test: test/images

# 类别数
nc: 2

# 类别名称
names: ['background', 'foreign_object']
"""

        config_path = Path("data/catenary_minimal.yaml")
        config_path.parent.mkdir(exist_ok=True)
        with open(config_path, 'w', encoding='utf-8') as f:
            f.write(config_content)

        print(f"✓ 创建数据集配置文件: {config_path}")
        return base_dir

    @staticmethod
    def _create_single_image(base_dir, split, idx):
        """创建单张图像"""
        img_size = 640

        # 创建背景（天空）
        sky_color = np.array([135, 206, 235])  # 天蓝色
        img = np.full((img_size, img_size, 3), sky_color, dtype=np.uint8)

        # 添加渐变
        for y in range(img_size):
            factor = y / img_size
            img[y, :, :] = img[y, :, :] * (1 - factor * 0.3)

        # 添加接触网结构
        img = DatasetCreator._add_catenary_structure(img)

        # 随机决定是否添加异物
        has_object = random.random() < 0.8  # 80%的图像有异物

        label_lines = []
        if has_object:
            # 创建随机异物（矩形）
            x = random.randint(100, img_size - 150)
            y = random.randint(100, img_size - 150)
            w = random.randint(30, 80)
            h = random.randint(30, 80)

            # 随机颜色（红色调，模拟异物）
            color = (random.randint(0, 100),
                     random.randint(0, 50),
                     random.randint(100, 255))

            # 绘制矩形异物
            cv2.rectangle(img, (x, y), (x + w, y + h), color, -1)

            # 添加一些纹理
            for _ in range(10):
                rx = random.randint(x, x + w)
                ry = random.randint(y, y + h)
                cv2.circle(img, (rx, ry), random.randint(1, 3),
                           (color[0] // 2, color[1] // 2, color[2] // 2), -1)

            # 转换为YOLO格式
            x_center = (x + w / 2) / img_size
            y_center = (y + h / 2) / img_size
            width = w / img_size
            height = h / img_size

            label_lines.append(f"1 {x_center:.6f} {y_center:.6f} {width:.6f} {height:.6f}")

        # 保存图像
        img_path = base_dir / split / 'images' / f'img_{idx:04d}.jpg'
        cv2.imwrite(str(img_path), img)

        # 保存标签
        label_path = base_dir / split / 'labels' / f'img_{idx:04d}.txt'
        with open(label_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(label_lines))

    @staticmethod
    def _add_catenary_structure(img):
        """添加接触网结构"""
        h, w = img.shape[:2]

        # 添加电线杆（随机位置）
        pole_x = w // 2 + random.randint(-100, 100)
        pole_width = 15
        pole_height = h // 3 + random.randint(-50, 50)

        # 电线杆
        cv2.rectangle(img,
                      (pole_x - pole_width // 2, h - pole_height),
                      (pole_x + pole_width // 2, h),
                      (80, 80, 80), -1)

        # 电线
        wire_y = h - pole_height + 40
        wire_thickness = 2
        cv2.line(img, (50, wire_y), (w - 50, wire_y),
                 (60, 60, 60), wire_thickness)

        # 吊弦（随机数量）
        num_droppers = random.randint(3, 8)
        for i in range(num_droppers):
            x_pos = int((w - 100) * i / (num_droppers - 1)) + 50 if num_droppers > 1 else w // 2
            cv2.line(img, (x_pos, wire_y), (x_pos, wire_y + 30),
                     (70, 70, 70), 1)

        return img

    @staticmethod
    def create_synthetic_dataset(output_dir="./datasets/catenary_synthetic", num_images=1000):
        """
        创建合成数据集（更复杂）

        Args:
            output_dir: 输出目录
            num_images: 图像数量
        """
        print(f"创建合成数据集到 {output_dir}...")
        # 这里可以扩展更复杂的合成逻辑
        return DatasetCreator.create_minimal_dataset(output_dir, num_images)


class DataAugmentor:
    """数据增强器"""

    def __init__(self):
        self.transform = A.Compose([
            # 几何变换
            A.RandomRotate90(p=0.3),
            A.HorizontalFlip(p=0.5),
            A.ShiftScaleRotate(
                shift_limit=0.05,
                scale_limit=0.1,
                rotate_limit=10,
                border_mode=cv2.BORDER_CONSTANT,
                value=(135, 206, 235),  # 天空颜色
                p=0.5
            ),

            # 颜色变换
            A.RandomBrightnessContrast(
                brightness_limit=0.1,
                contrast_limit=0.1,
                p=0.3
            ),
            A.HueSaturationValue(
                hue_shift_limit=5,
                sat_shift_limit=10,
                val_shift_limit=10,
                p=0.3
            ),

            # 模糊和噪声
            A.GaussNoise(var_limit=(5.0, 20.0), p=0.2),
            A.GaussianBlur(blur_limit=(3, 5), p=0.2),

            # 天气效果
            A.RandomFog(fog_coef_lower=0.01, fog_coef_upper=0.1, p=0.1),
        ], bbox_params=A.BboxParams(
            format='yolo',
            label_fields=['class_labels']
        ))

    def augment_batch(self, images_dir, labels_dir, output_dir, num_augmentations=3):
        """
        批量增强数据

        Args:
            images_dir: 原始图像目录
            labels_dir: 原始标签目录
            output_dir: 输出目录
            num_augmentations: 每张图像的增强次数
        """
        images_dir = Path(images_dir)
        labels_dir = Path(labels_dir)
        output_dir = Path(output_dir)

        output_dir.mkdir(parents=True, exist_ok=True)
        (output_dir / 'images').mkdir(exist_ok=True)
        (output_dir / 'labels').mkdir(exist_ok=True)

        image_files = list(images_dir.glob('*.jpg')) + list(images_dir.glob('*.png'))

        print(f"开始增强 {len(image_files)} 张图像...")

        for img_idx, img_path in enumerate(image_files):
            # 读取图像
            image = cv2.imread(str(img_path))
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

            # 读取标签
            label_path = labels_dir / f"{img_path.stem}.txt"
            bboxes = []
            class_labels = []

            if label_path.exists():
                with open(label_path, 'r') as f:
                    lines = f.readlines()
                    for line in lines:
                        parts = line.strip().split()
                        if len(parts) == 5:
                            class_id = int(parts[0])
                            x_center = float(parts[1])
                            y_center = float(parts[2])
                            width = float(parts[3])
                            height = float(parts[4])

                            bboxes.append([x_center, y_center, width, height])
                            class_labels.append(class_id)

            # 原始图像复制一份
            cv2.imwrite(str(output_dir / 'images' / f"{img_path.stem}_orig.jpg"),
                        cv2.cvtColor(image, cv2.COLOR_RGB2BGR))

            if bboxes:
                with open(output_dir / 'labels' / f"{img_path.stem}_orig.txt", 'w') as f:
                    for bbox, cls in zip(bboxes, class_labels):
                        f.write(f"{cls} {bbox[0]:.6f} {bbox[1]:.6f} {bbox[2]:.6f} {bbox[3]:.6f}\n")

            # 增强图像
            for aug_idx in range(num_augmentations):
                if bboxes:
                    transformed = self.transform(
                        image=image,
                        bboxes=bboxes,
                        class_labels=class_labels
                    )
                    aug_image = transformed['image']
                    aug_bboxes = transformed['bboxes']
                else:
                    transformed = self.transform(image=image)
                    aug_image = transformed['image']
                    aug_bboxes = []

                # 保存增强后的图像
                aug_img_path = output_dir / 'images' / f"{img_path.stem}_aug{aug_idx}.jpg"
                cv2.imwrite(str(aug_img_path),
                            cv2.cvtColor(aug_image, cv2.COLOR_RGB2BGR))

                # 保存增强后的标签
                if aug_bboxes:
                    aug_label_path = output_dir / 'labels' / f"{img_path.stem}_aug{aug_idx}.txt"
                    with open(aug_label_path, 'w') as f:
                        for bbox, cls in zip(aug_bboxes, class_labels):
                            f.write(f"{cls} {bbox[0]:.6f} {bbox[1]:.6f} {bbox[2]:.6f} {bbox[3]:.6f}\n")

                print(f"  增强 {img_path.stem} - {aug_idx + 1}/{num_augmentations}")

        print(f"✓ 数据增强完成，输出到 {output_dir}")


class FormatConverter:
    """格式转换器"""

    @staticmethod
    def coco_to_yolo(coco_json_path, output_dir, class_mapping=None):
        """
        将COCO格式转换为YOLO格式

        Args:
            coco_json_path: COCO JSON文件路径
            output_dir: 输出目录
            class_mapping: 类别映射 {coco_id: yolo_id}
        """
        import json

        with open(coco_json_path, 'r') as f:
            coco_data = json.load(f)

        # 默认类别映射
        if class_mapping is None:
            class_mapping = {}
            for i, cat in enumerate(coco_data['categories']):
                class_mapping[cat['id']] = i

        # 创建图像映射
        images = {img['id']: img for img in coco_data['images']}

        # 按图像分组标注
        annotations_by_image = {}
        for ann in coco_data['annotations']:
            img_id = ann['image_id']
            if img_id not in annotations_by_image:
                annotations_by_image[img_id] = []
            annotations_by_image[img_id].append(ann)

        # 创建输出目录
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        # 转换每个图像
        for img_id, img_info in images.items():
            img_name = img_info['file_name']
            img_width = img_info['width']
            img_height = img_info['height']

            label_lines = []
            if img_id in annotations_by_image:
                for ann in annotations_by_image[img_id]:
                    # COCO格式: [x, y, width, height]
                    x, y, w, h = ann['bbox']

                    # 转换为YOLO格式
                    x_center = (x + w / 2) / img_width
                    y_center = (y + h / 2) / img_height
                    width = w / img_width
                    height = h / img_height

                    # 获取类别ID
                    coco_class_id = ann['category_id']
                    yolo_class_id = class_mapping.get(coco_class_id, 0)

                    label_lines.append(f"{yolo_class_id} {x_center:.6f} {y_center:.6f} {width:.6f} {height:.6f}")

            # 保存标签文件
            label_name = img_name.rsplit('.', 1)[0] + '.txt'
            label_path = output_dir / label_name

            with open(label_path, 'w') as f:
                f.write('\n'.join(label_lines))

        print(f"✓ COCO转YOLO完成，共转换 {len(images)} 张图像")

    @staticmethod
    def split_dataset(data_dir, train_ratio=0.7, val_ratio=0.2, test_ratio=0.1):
        """
        分割数据集

        Args:
            data_dir: 数据目录（包含images和labels子目录）
            train_ratio: 训练集比例
            val_ratio: 验证集比例
            test_ratio: 测试集比例
        """
        data_dir = Path(data_dir)
        images_dir = data_dir / 'images'
        labels_dir = data_dir / 'labels'

        # 获取所有图像文件
        image_files = list(images_dir.glob('*.jpg')) + list(images_dir.glob('*.png'))
        image_files = [f for f in image_files if f.is_file()]

        # 随机打乱
        random.shuffle(image_files)

        # 计算分割点
        total = len(image_files)
        train_end = int(total * train_ratio)
        val_end = train_end + int(total * val_ratio)

        splits = {
            'train': image_files[:train_end],
            'val': image_files[train_end:val_end],
            'test': image_files[val_end:]
        }

        # 创建分割目录
        for split in ['train', 'val', 'test']:
            split_dir = data_dir / split
            (split_dir / 'images').mkdir(parents=True, exist_ok=True)
            (split_dir / 'labels').mkdir(parents=True, exist_ok=True)

        # 复制文件
        for split, files in splits.items():
            print(f"处理 {split} 集: {len(files)} 张图像")

            for img_file in files:
                # 复制图像
                dst_img = data_dir / split / 'images' / img_file.name
                if not dst_img.exists():
                    import shutil
                    shutil.copy2(img_file, dst_img)

                # 复制标签
                label_file = labels_dir / f"{img_file.stem}.txt"
                dst_label = data_dir / split / 'labels' / f"{img_file.stem}.txt"
                if label_file.exists() and not dst_label.exists():
                    shutil.copy2(label_file, dst_label)

        print(f"✓ 数据集分割完成")
        print(f"  训练集: {len(splits['train'])} 张")
        print(f"  验证集: {len(splits['val'])} 张")
        print(f"  测试集: {len(splits['test'])} 张")


def create_dataset_pipeline():
    """创建数据集的工作流程"""
    print("=" * 50)
    print("数据集创建流程")
    print("=" * 50)

    print("\n步骤1: 创建最小数据集（用于测试）")
    creator = DatasetCreator()
    creator.create_minimal_dataset(num_images=100)

    print("\n步骤2: 创建完整合成数据集")
    creator.create_synthetic_dataset(num_images=1000)

    print("\n步骤3: 数据增强示例")
    augmentor = DataAugmentor()
    # 注意：这里需要先有真实数据才能增强

    print("\n✓ 数据集工具准备完成！")
    print("\n使用方法:")
    print("1. 创建测试数据集: python scripts/create_dataset.py --type minimal")
    print("2. 增强数据: python scripts/augment_data.py --input-dir datasets/raw")
    print("3. 转换格式: python scripts/convert_format.py --format coco2yolo")


if __name__ == "__main__":
    create_dataset_pipeline()