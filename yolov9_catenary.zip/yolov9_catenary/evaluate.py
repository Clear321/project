import argparse
import os
import torch
import numpy as np
from sklearn.metrics import precision_recall_curve, average_precision_score
import matplotlib.pyplot as plt
from pathlib import Path
import sys

sys.path.append(str(Path(__file__).parent))

from models.yolo import YOLOv9_Catenary
from train import CatenaryDataset


def evaluate_model(model, dataloader, device, iou_threshold=0.5):
    """评估模型性能"""
    model.eval()

    all_predictions = []
    all_targets = []

    with torch.no_grad():
        for batch_idx, (images, targets) in enumerate(dataloader):
            images = images.to(device)

            # 前向传播
            predictions = model(images)

            # 处理预测结果
            batch_predictions = self.process_predictions(predictions)
            all_predictions.extend(batch_predictions)

            # 处理目标
            batch_targets = self.process_targets(targets)
            all_targets.extend(batch_targets)

            if batch_idx % 10 == 0:
                print(f'Processed {batch_idx}/{len(dataloader)} batches')

    # 计算评估指标
    metrics = self.calculate_metrics(all_predictions, all_targets, iou_threshold)

    return metrics


def process_predictions(self, predictions):
    """处理预测结果"""
    batch_predictions = []

    # 获取批量大小
    batch_size = predictions['cls'].shape[0]

    for i in range(batch_size):
        # 获取当前样本的预测
        cls_pred = predictions['cls'][i]  # (nc, H, W)
        reg_pred = predictions['reg'][i]  # (4, H, W)
        mask_pred = predictions['mask'][i]  # (1, H, W)
        conf_pred = predictions['conf'][i]  # (1, H, W)

        # 获取高置信度位置
        conf_mask = conf_pred > 0.1  # 低阈值以获取更多预测

        if not conf_mask.any():
            batch_predictions.append([])
            continue

        # 获取预测信息
        sample_predictions = []
        conf_indices = torch.where(conf_mask)

        for idx in range(len(conf_indices[0])):
            h_idx, w_idx = conf_indices[1][idx].item(), conf_indices[2][idx].item()

            # 获取边界框（归一化坐标）
            bbox = reg_pred[:, h_idx, w_idx].cpu().numpy()

            # 获取置信度
            confidence = conf_pred[0, h_idx, w_idx].item()

            # 获取类别
            class_scores = cls_pred[:, h_idx, w_idx]
            class_id = torch.argmax(class_scores).item()
            class_score = class_scores[class_id].item()

            # 获取掩码
            mask = mask_pred[0, h_idx, w_idx].cpu().numpy()

            sample_predictions.append({
                'bbox': bbox,
                'confidence': confidence,
                'class_id': class_id,
                'class_score': class_score,
                'mask': mask
            })

        batch_predictions.append(sample_predictions)

    return batch_predictions


def process_targets(self, targets):
    """处理目标"""
    batch_targets = []

    for target in targets:
        boxes = target['boxes'].cpu().numpy()
        masks = target['masks'].cpu().numpy()

        sample_targets = []
        for i in range(len(boxes)):
            sample_targets.append({
                'bbox': boxes[i],
                'mask': masks[i] if i < len(masks) else None
            })

        batch_targets.append(sample_targets)

    return batch_targets


def calculate_metrics(self, predictions, targets, iou_threshold=0.5):
    """计算评估指标"""
    # 计算每个类别的AP
    ap_scores = []
    precision_list = []
    recall_list = []

    for class_id in range(1, self.num_classes):  # 跳过背景类
        # 收集所有预测和目标的置信度、IoU
        pred_confidences = []
        target_matches = []

        for pred_list, target_list in zip(predictions, targets):
            # 过滤当前类别的预测
            class_preds = [p for p in pred_list if p['class_id'] == class_id]

            if not class_preds or not target_list:
                continue

            # 计算每个预测与目标的IoU
            for pred in class_preds:
                best_iou = 0
                best_target_idx = -1

                for t_idx, target in enumerate(target_list):
                    iou = self.calculate_iou(pred['bbox'], target['bbox'])
                    if iou > best_iou:
                        best_iou = iou
                        best_target_idx = t_idx

                # 记录预测
                pred_confidences.append(pred['confidence'])
                target_matches.append(best_iou >= iou_threshold)

        if pred_confidences:
            # 计算PR曲线和AP
            ap = average_precision_score(target_matches, pred_confidences)
            precision, recall, _ = precision_recall_curve(target_matches, pred_confidences)

            ap_scores.append(ap)
            precision_list.append(precision)
            recall_list.append(recall)

    # 计算平均指标
    metrics = {
        'mAP': np.mean(ap_scores) if ap_scores else 0,
        'AP_per_class': ap_scores,
        'precision_curve': precision_list,
        'recall_curve': recall_list
    }

    return metrics


def plot_pr_curve(precision, recall, ap, save_path=None):
    """绘制PR曲线"""
    plt.figure(figsize=(10, 8))

    plt.plot(recall, precision, label=f'AP = {ap:.3f}')
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title('Precision-Recall Curve')
    plt.legend()
    plt.grid(True)

    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')

    plt.show()


def main():
    parser = argparse.ArgumentParser(description='Evaluate YOLOv9 model for catenary detection')
    parser.add_argument('--model-path', type=str, required=True, help='Path to trained model')
    parser.add_argument('--data-dir', type=str, required=True, help='Dataset directory')
    parser.add_argument('--img-size', type=int, default=640, help='Input image size')
    parser.add_argument('--batch-size', type=int, default=4, help='Batch size')
    parser.add_argument('--iou-threshold', type=float, default=0.5, help='IoU threshold')
    parser.add_argument('--output-dir', type=str, default='./evaluation', help='Output directory')

    args = parser.parse_args()

    # 创建输出目录
    os.makedirs(args.output_dir, exist_ok=True)

    # 设置设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # 加载模型
    checkpoint = torch.load(args.model_path, map_location=device)
    model_args = checkpoint['args']

    model = YOLOv9_Catenary(nc=model_args.num_classes).to(device)
    model.load_state_dict(checkpoint['model_state_dict'])

    # 加载数据集
    val_dataset = CatenaryDataset(
        args.data_dir,
        split='val',
        transform=None,
        img_size=args.img_size
    )

    val_loader = torch.utils.data.DataLoader(
        val_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=4,
        collate_fn=lambda x: tuple(zip(*x))
    )

    # 评估模型
    print("Evaluating model...")
    metrics = evaluate_model(model, val_loader, device, args.iou_threshold)

    # 打印结果
    print(f"\nEvaluation Results:")
    print(f"mAP@0.5: {metrics['mAP']:.4f}")

    for i, ap in enumerate(metrics['AP_per_class']):
        print(f"Class {i + 1} AP: {ap:.4f}")

    # 绘制PR曲线
    if metrics['precision_curve']:
        for i, (precision, recall) in enumerate(zip(metrics['precision_curve'], metrics['recall_curve'])):
            plot_pr_curve(
                precision, recall, metrics['AP_per_class'][i],
                save_path=os.path.join(args.output_dir, f'pr_curve_class_{i + 1}.png')
            )

    # 保存评估结果
    result_file = os.path.join(args.output_dir, 'evaluation_results.txt')
    with open(result_file, 'w') as f:
        f.write(f"Evaluation Results:\n")
        f.write(f"mAP@0.5: {metrics['mAP']:.4f}\n")
        for i, ap in enumerate(metrics['AP_per_class']):
            f.write(f"Class {i + 1} AP: {ap:.4f}\n")

    print(f"\nResults saved to {args.output_dir}")


if __name__ == '__main__':
    main()