import torch
import torch.nn as nn
import torch.nn.functional as F


class YOLOv9_Catenary(nn.Module):
    """YOLOv9模型 - 终极简化版本"""

    def __init__(self, nc=2, ch=3, img_size=640):
        super().__init__()
        self.nc = nc
        self.img_size = img_size

        print(f"初始化YOLOv9模型，类别数: {nc}")

        # 1. 主干网络
        self.stem = nn.Sequential(
            # 输入: (B, 3, H, W)
            nn.Conv2d(ch, 32, 3, 2, 1),  # /2 -> (B, 32, H/2, W/2)
            nn.BatchNorm2d(32),
            nn.SiLU(),
            nn.Conv2d(32, 64, 3, 2, 1),  # /4 -> (B, 64, H/4, W/4)
            nn.BatchNorm2d(64),
            nn.SiLU(),
        )

        # 2. 特征提取
        self.stage1 = self._make_stage(64, 128)  # /8
        self.stage2 = self._make_stage(128, 256)  # /16
        self.stage3 = self._make_stage(256, 512)  # /32

        # 3. 特征金字塔网络 (FPN)
        # 横向连接
        self.fpn_lateral3 = nn.Conv2d(512, 256, 1)
        self.fpn_lateral2 = nn.Conv2d(256, 256, 1)
        self.fpn_lateral1 = nn.Conv2d(128, 256, 1)

        # 输出卷积
        self.fpn_output3 = nn.Conv2d(256, 256, 3, padding=1)
        self.fpn_output2 = nn.Conv2d(256, 256, 3, padding=1)
        self.fpn_output1 = nn.Conv2d(256, 256, 3, padding=1)

        # 4. 检测头
        self.detect_head = DetectHead(256, nc)

        # 5. 初始化权重
        self._initialize_weights()

    def _make_stage(self, in_channels, out_channels):
        """构建特征提取阶段"""
        return nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, 2, 1),  # 下采样
            nn.BatchNorm2d(out_channels),
            nn.SiLU(),
            nn.Conv2d(out_channels, out_channels, 3, 1, 1),  # 特征提取
            nn.BatchNorm2d(out_channels),
            nn.SiLU(),
        )

    def _initialize_weights(self):
        """初始化权重"""
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def forward(self, x):
        B, C, H, W = x.shape

        # 1. 主干特征提取
        x0 = self.stem(x)  # (B, 64, H/4, W/4)

        # 2. 多尺度特征提取
        c1 = self.stage1(x0)  # (B, 128, H/8, W/8)
        c2 = self.stage2(c1)  # (B, 256, H/16, W/16)
        c3 = self.stage3(c2)  # (B, 512, H/32, W/32)

        # 3. FPN特征融合
        # 自顶向下路径
        p3 = self.fpn_lateral3(c3)  # (B, 256, H/32, W/32)
        p3_up = F.interpolate(p3, scale_factor=2, mode='bilinear', align_corners=False)

        p2 = self.fpn_lateral2(c2) + p3_up  # (B, 256, H/16, W/16)
        p2_up = F.interpolate(p2, scale_factor=2, mode='bilinear', align_corners=False)

        p1 = self.fpn_lateral1(c1) + p2_up  # (B, 256, H/8, W/8)

        # FPN输出
        f3 = self.fpn_output3(p3)  # 低分辨率特征
        f2 = self.fpn_output2(p2)  # 中分辨率特征
        f1 = self.fpn_output1(p1)  # 高分辨率特征

        # 4. 多尺度特征融合
        # 上采样到统一尺寸（使用最高分辨率f1）
        H_target, W_target = f1.shape[2:]

        f3_up = F.interpolate(f3, size=(H_target, W_target), mode='bilinear', align_corners=False)
        f2_up = F.interpolate(f2, size=(H_target, W_target), mode='bilinear', align_corners=False)

        # 特征融合
        fused_features = torch.cat([f1, f2_up, f3_up], dim=1)  # (B, 768, H/8, W/8)

        # 融合卷积
        fusion_conv = nn.Conv2d(768, 256, 1).to(fused_features.device)
        fused_features = fusion_conv(fused_features)  # (B, 256, H/8, W/8)

        # 5. 检测头
        outputs = self.detect_head(fused_features)

        # 6. 上采样到原始尺寸
        for key in ['cls', 'reg', 'mask', 'conf']:
            if key in outputs:
                outputs[key] = F.interpolate(
                    outputs[key],
                    size=(H, W),
                    mode='bilinear',
                    align_corners=False
                )

        # 添加refined_mask（与mask相同）
        outputs['refined_mask'] = outputs['mask'].clone()
        outputs['feature_size'] = (H_target, W_target)
        outputs['original_size'] = (H, W)

        return outputs


class DetectHead(nn.Module):
    """检测头 - 简化版本"""

    def __init__(self, in_channels, nc):
        super().__init__()
        self.nc = nc

        # 分类分支
        self.cls_conv = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, 3, padding=1),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(),
            nn.Conv2d(in_channels, nc, 1)
        )

        # 回归分支（边界框）
        self.reg_conv = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, 3, padding=1),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(),
            nn.Conv2d(in_channels, 4, 1),
            nn.Sigmoid()  # 归一化到[0, 1]
        )

        # 掩码分支
        self.mask_conv = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, 3, padding=1),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(),
            nn.Conv2d(in_channels, 1, 1),
            nn.Sigmoid()
        )

        # 置信度分支
        self.conf_conv = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, 3, padding=1),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(),
            nn.Conv2d(in_channels, 1, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        """前向传播"""
        cls_output = self.cls_conv(x)  # (B, nc, H, W)
        reg_output = self.reg_conv(x)  # (B, 4, H, W)
        mask_output = self.mask_conv(x)  # (B, 1, H, W)
        conf_output = self.conf_conv(x)  # (B, 1, H, W)

        return {
            'cls': cls_output,
            'reg': reg_output,
            'mask': mask_output,
            'conf': conf_output
        }


def test_model():
    """测试模型"""
    print("测试YOLOv9模型...")

    try:
        # 创建模型
        model = YOLOv9_Catenary(nc=2)
        print(f"✓ 模型创建成功")

        # 统计参数
        total_params = sum(p.numel() for p in model.parameters())
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        print(f"总参数量: {total_params:,}")
        print(f"可训练参数: {trainable_params:,}")

        # 测试前向传播
        x = torch.randn(2, 3, 640, 640)
        outputs = model(x)

        print(f"✓ 前向传播成功")
        print(f"输入尺寸: {x.shape}")

        # 打印输出形状
        for key, value in outputs.items():
            if isinstance(value, torch.Tensor):
                print(f"{key}: {value.shape}")
            elif key in ['feature_size', 'original_size']:
                print(f"{key}: {value}")

        return True

    except Exception as e:
        print(f"✗ 错误: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    test_model()