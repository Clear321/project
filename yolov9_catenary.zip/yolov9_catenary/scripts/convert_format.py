#!/usr/bin/env python
"""
格式转换脚本
    python convert_format.py --format coco2yolo --input ./coco.json --output ./yolo_labels
"""
import argparse
import sys
from pathlib import Path
import json

project_root = Path(__file__).parent.parent
sys.path.append(str(project_root))

from utils.dataset_tools import FormatConverter


def main():
    parser = argparse.ArgumentParser(description="格式转换")
    parser.add_argument("--format", type=str, required=True,
                        choices=["coco2yolo", "split"],
                        help="转换格式")
    parser.add_argument("--input", type=str, required=True,
                        help="输入文件或目录")
    parser.add_argument("--output", type=str,
                        help="输出目录")
    parser.add_argument("--class-mapping", type=str,
                        help="类别映射JSON文件")

    args = parser.parse_args()

    if args.format == "coco2yolo":
        if not args.output:
            args.output = Path(args.input).parent / "yolo_labels"

        class_mapping = None
        if args.class_mapping:
            with open(args.class_mapping, 'r') as f:
                class_mapping = json.load(f)

        print(f"COCO转YOLO: {args.input} -> {args.output}")
        FormatConverter.coco_to_yolo(args.input, args.output, class_mapping)

    elif args.format == "split":
        if not args.output:
            args.output = args.input

        print(f"分割数据集: {args.input}")
        FormatConverter.split_dataset(args.input)

    print("✓ 转换完成！")


if __name__ == "__main__":
    main()