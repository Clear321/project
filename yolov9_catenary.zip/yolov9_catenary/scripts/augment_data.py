#!/usr/bin/env python
"""
数据增强脚本
    python augment_data.py --input-dir ./datasets/raw --output ./datasets/augmented
"""
import argparse
import sys
from pathlib import Path

project_root = Path(__file__).parent.parent
sys.path.append(str(project_root))

from utils.dataset_tools import DataAugmentor


def main():
    parser = argparse.ArgumentParser(description="数据增强")
    parser.add_argument("--input-dir", type=str, required=True,
                        help="输入目录（包含images和labels）")
    parser.add_argument("--output-dir", type=str, default="./datasets/augmented",
                        help="输出目录")
    parser.add_argument("--num-augmentations", type=int, default=3,
                        help="每张图像的增强次数")

    args = parser.parse_args()

    print(f"数据增强: {args.input_dir} -> {args.output_dir}")
    print(f"每张图像增强 {args.num_augmentations} 次")

    augmentor = DataAugmentor()
    augmentor.augment_batch(
        Path(args.input_dir) / 'images',
        Path(args.input_dir) / 'labels',
        args.output_dir,
        args.num_augmentations
    )

    print("✓ 增强完成！")


if __name__ == "__main__":
    main()