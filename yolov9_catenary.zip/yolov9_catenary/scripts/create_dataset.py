#!/usr/bin/env python
"""
数据集创建脚本
    python create_dataset.py --type minimal --output ./datasets/minimal
    python create_dataset.py --type synthetic --num-images 1000
"""
import argparse
import sys
from pathlib import Path

# 添加项目根目录到Python路径
project_root = Path(__file__).parent.parent
sys.path.append(str(project_root))

from utils.dataset_tools import DatasetCreator, FormatConverter


def main():
    parser = argparse.ArgumentParser(description="创建接触网异物检测数据集")
    parser.add_argument("--type", type=str, default="minimal",
                        choices=["minimal", "synthetic", "split"],
                        help="数据集类型")
    parser.add_argument("--output", type=str, default="./datasets/catenary_minimal",
                        help="输出目录")
    parser.add_argument("--num-images", type=int, default=100,
                        help="图像数量")
    parser.add_argument("--split-ratios", type=float, nargs=3,
                        default=[0.7, 0.2, 0.1],
                        help="分割比例 [train val test]")

    args = parser.parse_args()

    if args.type == "minimal":
        print(f"创建最小数据集 ({args.num_images} 张图像)...")
        DatasetCreator.create_minimal_dataset(args.output, args.num_images)

    elif args.type == "synthetic":
        print(f"创建合成数据集 ({args.num_images} 张图像)...")
        DatasetCreator.create_synthetic_dataset(args.output, args.num_images)

    elif args.type == "split":
        print(f"分割数据集到 {args.output}...")
        FormatConverter.split_dataset(
            args.output,
            train_ratio=args.split_ratios[0],
            val_ratio=args.split_ratios[1],
            test_ratio=args.split_ratios[2]
        )

    print("✓ 完成！")


if __name__ == "__main__":
    main()