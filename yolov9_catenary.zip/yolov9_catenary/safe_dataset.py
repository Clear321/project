# safe_dataset.py
"""
安全的数据集加载器，确保所有数据都是tensor格式
"""
import torch
from torch.utils.data import Dataset
from PIL import Image
import torchvision.transforms as transforms
from pathlib import Path
import numpy as np


class SafeCatenaryDataset(Dataset):
    """安全的数据集类，确保数据格式正确"""

    def __init__(self, images_dir, img_size=320):
        """
        初始化数据集

        Args:
            images_dir: 图像目录路径
            img_size: 图像尺寸
        """
        self.images_dir = Path(images_dir)
        self.img_size = img_size

        # 自动推断标签目录
        if (self.images_dir.parent / 'labels').exists():
            self.labels_dir = self.images_dir.parent / 'labels'
        else:
            self.labels_dir = self.images_dir

        # 获取所有图像文件
        self.img_files = sorted(
            list(self.images_dir.glob('*.jpg')) +
            list(self.images_dir.glob('*.png')) +
            list(self.images_dir.glob('*.jpeg'))
        )

        if len(self.img_files) == 0:
            raise FileNotFoundError(f"在 {self.images_dir} 中没有找到图像文件")

        print(f"加载数据集: {len(self.img_files)} 张图像")

    def __len__(self):
        return len(self.img_files)

    def __getitem__(self, idx):
        # 加载图像
        img_path = self.img_files[idx]
        img = Image.open(img_path).convert('RGB')

        # 图像预处理
        transform = transforms.Compose([
            transforms.Resize((self.img_size, self.img_size)),
            transforms.ToTensor(),
        ])
        img_tensor = transform(img)

        # 加载标签
        label_path = self.labels_dir / f"{img_path.stem}.txt"

        if label_path.exists():
            # 安全地加载边界框
            boxes, labels = self._safe_load_label(label_path, self.img_size)
        else:
            # 没有标签的情况
            boxes = torch.zeros((0, 4), dtype=torch.float32)
            labels = torch.zeros((0,), dtype=torch.long)

        # 创建掩码（简化版本）
        mask = torch.zeros((1, self.img_size, self.img_size), dtype=torch.float32)

        # 返回数据 - 确保所有都是tensor
        return img_tensor, {
            'boxes': boxes,  # tensor [N, 4]
            'labels': labels,  # tensor [N]
            'masks': mask,  # tensor [1, H, W]
            'image_id': torch.tensor([idx]),
        }

    def _safe_load_label(self, label_path, img_size):
        """安全地加载YOLO格式标签"""
        boxes = []
        labels = []

        try:
            with open(label_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue

                    parts = line.split()
                    if len(parts) >= 5:
                        try:
                            # 解析YOLO格式
                            class_id = int(float(parts[0]))  # 处理可能的浮点数
                            x_center = float(parts[1])
                            y_center = float(parts[2])
                            width = float(parts[3])
                            height = float(parts[4])

                            # 验证值范围
                            if not (0 <= x_center <= 1 and 0 <= y_center <= 1 and
                                    0 <= width <= 1 and 0 <= height <= 1):
                                print(f"警告: {label_path} 中的值超出范围")
                                continue

                            # 转换为绝对坐标 (xyxy格式)
                            x_center_abs = x_center * img_size
                            y_center_abs = y_center * img_size
                            width_abs = width * img_size
                            height_abs = height * img_size

                            x1 = max(0, x_center_abs - width_abs / 2)
                            y1 = max(0, y_center_abs - height_abs / 2)
                            x2 = min(img_size, x_center_abs + width_abs / 2)
                            y2 = min(img_size, y_center_abs + height_abs / 2)

                            # 确保框有效
                            if x2 > x1 and y2 > y1:
                                boxes.append([x1, y1, x2, y2])
                                labels.append(class_id)

                        except (ValueError, IndexError) as e:
                            print(f"警告: 解析标签行失败 '{line}': {e}")
                            continue

        except Exception as e:
            print(f"错误: 读取标签文件 {label_path} 失败: {e}")

        # 转换为tensor - 关键步骤！
        if boxes:
            boxes_tensor = torch.tensor(boxes, dtype=torch.float32)
            labels_tensor = torch.tensor(labels, dtype=torch.long)
        else:
            boxes_tensor = torch.zeros((0, 4), dtype=torch.float32)
            labels_tensor = torch.zeros((0,), dtype=torch.long)

        return boxes_tensor, labels_tensor


def safe_collate_fn(batch):
    """安全的批处理函数"""
    images = []
    targets = []

    for img, target in batch:
        images.append(img)

        # 确保目标中的每个值都是tensor
        safe_target = {}
        for key, value in target.items():
            if isinstance(value, (list, tuple)):
                # 转换列表/元组为tensor
                safe_target[key] = torch.tensor(value)
            elif isinstance(value, np.ndarray):
                # 转换numpy数组为tensor
                safe_target[key] = torch.from_numpy(value)
            else:
                safe_target[key] = value

        targets.append(safe_target)

    images = torch.stack(images, dim=0)
    return images, targets


def test_safe_dataset():
    """测试安全数据集"""
    print("测试安全数据集...")

    # 创建测试数据集
    dataset = SafeCatenaryDataset(
        images_dir="./datasets/catenary_simple/train/images",
        img_size=320
    )

    print(f"数据集大小: {len(dataset)}")

    # 测试几个样本
    for i in range(min(3, len(dataset))):
        img, target = dataset[i]

        print(f"\n样本 {i}:")
        print(f"  图像形状: {img.shape}")
        print(f"  边界框类型: {type(target['boxes'])}, 形状: {target['boxes'].shape}")
        print(f"  标签类型: {type(target['labels'])}, 形状: {target['labels'].shape}")

        # 验证数据类型
        assert isinstance(target['boxes'], torch.Tensor), "边界框不是tensor!"
        assert isinstance(target['labels'], torch.Tensor), "标签不是tensor!"
        assert isinstance(target['masks'], torch.Tensor), "掩码不是tensor!"

        print("  ✓ 所有数据都是tensor格式")

    # 测试批处理
    from torch.utils.data import DataLoader

    dataloader = DataLoader(
        dataset,
        batch_size=2,
        shuffle=True,
        collate_fn=safe_collate_fn
    )

    print(f"\n测试数据加载器...")
    for batch_idx, (images, targets) in enumerate(dataloader):
        print(f"\n批次 {batch_idx}:")
        print(f"  图像: {images.shape}")
        print(f"  目标数量: {len(targets)}")

        # 检查第一个目标的格式
        for key, value in targets[0].items():
            if isinstance(value, torch.Tensor):
                print(f"  {key}: {value.shape} (tensor)")
            else:
                print(f"  {key}: {type(value)}")

        # 只测试第一个批次
        break

    print("\n✅ 安全数据集测试通过!")
    return True


if __name__ == "__main__":
    test_safe_dataset()