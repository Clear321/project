"""
YOLOv9接触网异物检测 - 训练脚本
    python train.py --data-config data/catenary.yaml
    python train.py --data-dir ./datasets/catenary --epochs 100
"""

import argparse
import random
import sys
import time
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.optim as optim
import torchvision.transforms as transforms
import yaml
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from torch.utils.tensorboard import SummaryWriter

# 添加项目根目录到Python路径
project_root = Path(__file__).parent
sys.path.append(str(project_root))

# 导入自定义模块
from models.yolo import YOLOv9_Catenary
from utils.loss import CatenaryLoss


def _load_yolo_label(label_path, img_size):
    """加载YOLO格式的标签文件"""
    boxes = []
    masks = []

    with open(label_path, 'r') as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) >= 5:
                # YOLO格式: class_id x_center y_center width height
                class_id = int(parts[0])

                # 只处理异物类别（class_id=1）
                if class_id != 1:
                    continue

                # 归一化坐标
                x_center = float(parts[1]) * img_size[0]
                y_center = float(parts[2]) * img_size[1]
                width = float(parts[3]) * img_size[0]
                height = float(parts[4]) * img_size[1]

                # 转换为xyxy格式
                x1 = x_center - width / 2
                y1 = y_center - height / 2
                x2 = x_center + width / 2
                y2 = y_center + height / 2

                boxes.append([x1, y1, x2, y2])

                # 创建矩形掩码
                mask = torch.zeros(img_size[1], img_size[0], dtype=torch.float32)
                x1_int, y1_int = max(0, int(x1)), max(0, int(y1))
                x2_int, y2_int = min(img_size[0], int(x2)), min(img_size[1], int(y2))

                if x2_int > x1_int and y2_int > y1_int:
                    mask[y1_int:y2_int, x1_int:x2_int] = 1

                masks.append(mask)

    if boxes:
        boxes_tensor = torch.tensor(boxes, dtype=torch.float32)
        masks_tensor = torch.stack(masks, dim=0) if masks else torch.zeros((1, img_size[1], img_size[0]))
    else:
        boxes_tensor = torch.zeros((0, 4), dtype=torch.float32)
        masks_tensor = torch.zeros((1, img_size[1], img_size[0]), dtype=torch.float32)

    return boxes_tensor, masks_tensor


class CatenaryDataset(Dataset):
    """接触网异物检测数据集"""

    def __init__(self, images_dir, labels_dir=None, img_size=640,
                 transform=None, augment=False, cache=False):
        """
        初始化数据集

        Args:
            images_dir: 图像目录路径
            labels_dir: 标签目录路径（如果为None，则从images_dir推断）
            img_size: 输入图像尺寸
            transform: 数据变换
            augment: 是否进行数据增强
            cache: 是否缓存图像到内存
        """
        self.images_dir = Path(images_dir)

        # 推断标签目录
        if labels_dir is None:
            # 尝试几种常见的标签目录结构
            possible_dirs = [
                self.images_dir.parent / 'labels',
                self.images_dir.parent.parent / 'labels' / self.images_dir.name,
                self.images_dir.with_name('labels'),
            ]
            for dir_path in possible_dirs:
                if dir_path.exists():
                    self.labels_dir = dir_path
                    break
            else:
                # 如果没有找到标签目录，则使用相同目录
                self.labels_dir = self.images_dir
        else:
            self.labels_dir = Path(labels_dir)

        # 获取所有图像文件
        self.img_files = sorted(
            list(self.images_dir.glob('*.jpg')) +
            list(self.images_dir.glob('*.jpeg')) +
            list(self.images_dir.glob('*.png')) +
            list(self.images_dir.glob('*.bmp'))
        )

        if len(self.img_files) == 0:
            raise FileNotFoundError(f"在 {self.images_dir} 中没有找到图像文件")

        self.img_size = img_size
        self.transform = transform
        self.augment = augment
        self.cache = cache

        # 如果启用缓存
        if cache:
            self.cached_images = []
            self.cached_targets = []
            print(f"正在缓存 {len(self.img_files)} 张图像...")
            for i in range(len(self.img_files)):
                img, target = self._load_item(i)
                self.cached_images.append(img)
                self.cached_targets.append(target)
            print("缓存完成!")

        print(f"数据集加载完成: {len(self.img_files)} 张图像")
        print(f"图像目录: {self.images_dir}")
        print(f"标签目录: {self.labels_dir}")

    def __len__(self):
        return len(self.img_files)

    def __getitem__(self, idx):
        if self.cache:
            return self.cached_images[idx], self.cached_targets[idx]
        else:
            return self._load_item(idx)

    def _load_item(self, idx):
        """加载单个数据项"""
        # 加载图像
        img_path = self.img_files[idx]
        img = Image.open(img_path).convert('RGB')
        orig_size = img.size  # (width, height)

        # 加载标签
        label_path = self._get_label_path(img_path)

        if label_path.exists():
            boxes, masks = _load_yolo_label(label_path, orig_size)
        else:
            # 如果没有标签文件，创建空的标签
            boxes = torch.zeros((0, 4), dtype=torch.float32)
            masks = torch.zeros((orig_size[1], orig_size[0]), dtype=torch.float32)

        # 数据增强
        if self.augment and self.transform and len(boxes) > 0:
            img, boxes, masks = self.transform(img, boxes, masks)

        # 调整图像大小
        img = transforms.Resize((self.img_size, self.img_size))(img)
        img_tensor = transforms.ToTensor()(img)

        # 调整掩码大小
        if masks.numel() > 0:
            # 将掩码调整为与图像相同大小
            masks_resized = []
            for i in range(masks.shape[0]):
                mask_pil = transforms.ToPILImage()(masks[i].unsqueeze(0))
                mask_resized = transforms.Resize((self.img_size, self.img_size))(mask_pil)
                mask_tensor = transforms.ToTensor()(mask_resized)
                masks_resized.append(mask_tensor)

            if masks_resized:
                masks_tensor = torch.stack(masks_resized).squeeze(1)
                # 合并所有掩码（假设异物不重叠）
                combined_mask = torch.max(masks_tensor, dim=0)[0]
            else:
                combined_mask = torch.zeros((self.img_size, self.img_size))
        else:
            combined_mask = torch.zeros((self.img_size, self.img_size))

        # 归一化边界框
        if len(boxes) > 0:
            boxes = boxes / torch.tensor([orig_size[0], orig_size[1], orig_size[0], orig_size[1]])

        # 创建目标字典
        target = {
            'boxes': boxes,
            'labels': torch.ones(len(boxes), dtype=torch.long),  # 异物类别ID=1
            'masks': combined_mask.unsqueeze(0),  # 添加通道维度
            'image_id': torch.tensor([idx]),
            'orig_size': torch.tensor(orig_size),
            'img_path': str(img_path)
        }

        return img_tensor, target

    def _get_label_path(self, img_path):
        """获取对应的标签文件路径"""
        label_name = f"{img_path.stem}.txt"

        # 尝试在标签目录中查找
        label_path = self.labels_dir / label_name
        if not label_path.exists():
            # 如果不存在，尝试其他可能的命名
            alt_names = [
                f"{img_path.stem}.txt",
                f"{img_path.stem}.json",
                f"{img_path.name}.txt",
            ]
            for name in alt_names:
                alt_path = self.labels_dir / name
                if alt_path.exists():
                    return alt_path

        return label_path


class DataAugmentation:
    """数据增强类 - 修复版本"""

    @staticmethod
    def transform(image, boxes, masks, augment=True):
        """
        数据增强变换

        Args:
            image: PIL图像
            boxes: 边界框张量
            masks: 掩码张量
            augment: 是否进行数据增强
        """
        # 确保 boxes 是张量
        if isinstance(boxes, (list, tuple)):
            # 如果是空列表
            if len(boxes) == 0:
                boxes = torch.zeros((0, 4), dtype=torch.float32)
            else:
                # 检查是否是嵌套结构
                if isinstance(boxes[0], (list, tuple)):
                    boxes = torch.tensor(boxes, dtype=torch.float32)
                else:
                    boxes = torch.tensor([boxes], dtype=torch.float32)

        # 如果 boxes 是空的，直接返回
        if boxes.numel() == 0:
            return image, boxes, masks

        img_np = np.array(image)
        h, w = img_np.shape[:2]

        # 只在训练时进行数据增强
        if augment:
            # 1. 随机水平翻转
            if random.random() < 0.5:
                img_np = img_np[:, ::-1, :].copy()  # 使用.copy()避免负步幅

                # 调整掩码
                if masks.numel() > 0:
                    masks = torch.flip(masks, dims=[2])

                # 调整边界框
                boxes = boxes.clone()  # 创建副本
                x1 = boxes[:, 0].clone()
                x2 = boxes[:, 2].clone()
                boxes[:, 0] = w - x2
                boxes[:, 2] = w - x1

            # 2. 随机缩放
            if random.random() < 0.5:
                scale = random.uniform(0.8, 1.2)

                # 计算新尺寸
                new_h = int(h * scale)
                new_w = int(w * scale)

                # 调整图像
                img_np = cv2.resize(img_np, (new_w, new_h))

                # 调整掩码
                if masks.numel() > 0:
                    masks_np = masks.numpy()
                    masks_resized = []
                    for i in range(masks.shape[0]):
                        mask_resized = cv2.resize(masks_np[i], (new_w, new_h), interpolation=cv2.INTER_NEAREST)
                        masks_resized.append(torch.from_numpy(mask_resized).float())

                    if masks_resized:
                        masks = torch.stack(masks_resized, dim=0)

                # 重要修复：正确缩放边界框
                boxes = boxes.clone().float()
                boxes[:, [0, 2]] = boxes[:, [0, 2]] * scale
                boxes[:, [1, 3]] = boxes[:, [1, 3]] * scale

                # 处理超出边界的框
                boxes[:, [0, 2]] = torch.clamp(boxes[:, [0, 2]], 0, new_w)
                boxes[:, [1, 3]] = torch.clamp(boxes[:, [1, 3]], 0, new_h)

                # 更新尺寸
                h, w = new_h, new_w

            # 3. 随机颜色抖动
            if random.random() < 0.3:
                # 亮度调整
                brightness = random.uniform(0.8, 1.2)
                img_np = np.clip(img_np.astype(np.float32) * brightness, 0, 255).astype(np.uint8)

                # 饱和度调整
                saturation = random.uniform(0.8, 1.2)
                hsv = cv2.cvtColor(img_np, cv2.COLOR_RGB2HSV)
                hsv[:, :, 1] = np.clip(hsv[:, :, 1] * saturation, 0, 255)
                img_np = cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)

        # 转换回 PIL 图像
        image = Image.fromarray(img_np)

        return image, boxes, masks

    @staticmethod
    def get_train_transform():
        """获取训练数据增强变换"""
        # 返回一个lambda函数或部分函数，引用静态方法
        return lambda image, boxes, masks: DataAugmentation.transform(image, boxes, masks, augment=True)

    @staticmethod
    def get_val_transform():
        """获取验证数据变换（无增强）"""
        return lambda image, boxes, masks: DataAugmentation.transform(image, boxes, masks, augment=False)

        return transform

    @staticmethod
    def get_val_transform():
        """获取验证数据变换（无增强）"""

        def transform(image, boxes, masks):
            return image, boxes, masks

        return transform


def collate_fn(batch):
    """自定义批处理函数"""
    images = []
    targets = []

    for img, target in batch:
        images.append(img)
        targets.append(target)

    images = torch.stack(images, dim=0)

    return images, targets


def load_data_config(config_path):
    """加载数据集配置文件 - 修复版本"""
    import yaml
    from pathlib import Path

    config_path = Path(config_path)

    if not config_path.exists():
        raise FileNotFoundError(f"配置文件不存在: {config_path}")

    with open(config_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)

    # 验证必要的配置项
    required_keys = ['path', 'train', 'val', 'nc', 'names']
    for key in required_keys:
        if key not in config:
            raise KeyError(f"配置文件中缺少必要的键: {key}")

    # ============ 关键修复：路径处理 ============
    data_path_str = config['path']

    # 获取项目根目录
    project_root = Path(__file__).parent

    # 处理相对路径
    if data_path_str.startswith('./'):
        # 相对于配置文件所在目录
        data_path = config_path.parent / data_path_str[2:]
    elif data_path_str.startswith('../'):
        # 相对于配置文件所在目录的上级
        data_path = config_path.parent.parent / data_path_str[3:]
    else:
        # 如果是绝对路径，直接使用
        if Path(data_path_str).is_absolute():
            data_path = Path(data_path_str)
        else:
            # 相对于项目根目录
            data_path = (project_root / data_path_str).resolve()

    print(f"原始路径: {data_path_str}")
    print(f"解析后路径: {data_path}")
    print(f"路径存在: {data_path.exists()}")

    # 如果路径不存在，尝试常见位置
    if not data_path.exists():
        print(f"⚠️ 警告: 数据集路径不存在，尝试备用路径...")

        # 尝试在项目根目录下查找
        possible_paths = [
            project_root / "datasets" / "catenary_simple",
            project_root / "datasets" / "catenary_minimal",
            project_root / "datasets" / "catenary",
            project_root / data_path_str,
        ]

        for possible_path in possible_paths:
            if possible_path.exists():
                data_path = possible_path
                print(f"  使用备用路径: {data_path}")
                break
        else:
            # 如果还是找不到，创建目录
            print(f"  创建目录: {data_path}")
            data_path.mkdir(parents=True, exist_ok=True)

    # 构建完整路径
    config['train'] = str(data_path / config['train'])
    config['val'] = str(data_path / config['val'])

    if 'test' in config:
        config['test'] = str(data_path / config['test'])

    print(f"数据集配置加载成功:")
    print(f"  数据集根目录: {data_path}")
    print(f"  训练集路径: {config['train']}")
    print(f"  验证集路径: {config['val']}")

    # 验证训练集路径
    train_path = Path(config['train'])
    if not train_path.exists():
        print(f"❌ 错误: 训练集路径不存在: {train_path}")
        print(f"  创建目录...")
        train_path.mkdir(parents=True, exist_ok=True)

    return config


class Trainer:
    """训练器类"""

    def __init__(self, model, train_loader, val_loader, criterion, optimizer,
                 scheduler, device, args, writer):
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.criterion = criterion
        self.optimizer = optimizer
        self.scheduler = scheduler
        self.device = device
        self.args = args
        self.writer = writer

        self.best_val_loss = float('inf')
        self.current_epoch = 0

        # 创建保存目录
        self.save_dir = Path(args.save_dir)
        self.save_dir.mkdir(parents=True, exist_ok=True)

        print(f"训练器初始化完成")
        print(f"  设备: {device}")
        print(f"  保存目录: {self.save_dir}")

    def train_epoch(self, epoch):
        """训练一个epoch"""
        self.model.train()

        epoch_loss = 0
        cls_loss_sum = 0
        reg_loss_sum = 0
        mask_loss_sum = 0
        boundary_loss_sum = 0

        num_batches = len(self.train_loader)

        print(f"\n{'=' * 60}")
        print(f"Epoch {epoch + 1}/{self.args.epochs}")
        print(f"{'=' * 60}")

        start_time = time.time()

        for batch_idx, (images, targets) in enumerate(self.train_loader):
            batch_start_time = time.time()

            # 将数据移动到设备
            images = images.to(self.device)

            # 准备目标
            batch_targets = self._prepare_targets(targets)

            # 前向传播
            predictions = self.model(images)

            # 计算损失
            total_loss, losses = self.criterion(predictions, batch_targets)

            # 反向传播
            self.optimizer.zero_grad()
            total_loss.backward()

            # 梯度裁剪
            if self.args.grad_clip > 0:
                torch.nn.utils.clip_grad_norm_(
                    self.model.parameters(),
                    self.args.grad_clip
                )

            self.optimizer.step()

            # 统计损失
            epoch_loss += total_loss.item()
            cls_loss_sum += losses['cls'].item()
            reg_loss_sum += losses['reg'].item()
            mask_loss_sum += losses['mask'].item()
            boundary_loss_sum += losses['boundary'].item()

            # 计算批处理时间
            batch_time = time.time() - batch_start_time

            # 打印进度
            if (batch_idx + 1) % self.args.print_freq == 0 or (batch_idx + 1) == num_batches:
                progress = (batch_idx + 1) / num_batches * 100
                avg_loss = epoch_loss / (batch_idx + 1)

                print(f"  Batch [{batch_idx + 1:3d}/{num_batches}] "
                      f"Progress: {progress:5.1f}% | "
                      f"Loss: {avg_loss:.4f} | "
                      f"Cls: {losses['cls'].item():.4f} | "
                      f"Reg: {losses['reg'].item():.4f} | "
                      f"Mask: {losses['mask'].item():.4f} | "
                      f"Time: {batch_time:.2f}s")

        # 计算epoch统计
        epoch_time = time.time() - start_time
        avg_epoch_loss = epoch_loss / num_batches

        print(f"\nEpoch {epoch + 1} 完成:")
        print(f"  总损失: {avg_epoch_loss:.4f}")
        print(f"  分类损失: {cls_loss_sum / num_batches:.4f}")
        print(f"  回归损失: {reg_loss_sum / num_batches:.4f}")
        print(f"  掩码损失: {mask_loss_sum / num_batches:.4f}")
        print(f"  边界损失: {boundary_loss_sum / num_batches:.4f}")
        print(f"  时间: {epoch_time:.1f}秒")

        # 记录到TensorBoard
        self.writer.add_scalar('Loss/train_total', avg_epoch_loss, epoch)
        self.writer.add_scalar('Loss/train_cls', cls_loss_sum / num_batches, epoch)
        self.writer.add_scalar('Loss/train_reg', reg_loss_sum / num_batches, epoch)
        self.writer.add_scalar('Loss/train_mask', mask_loss_sum / num_batches, epoch)
        self.writer.add_scalar('Loss/train_boundary', boundary_loss_sum / num_batches, epoch)
        self.writer.add_scalar('LearningRate', self.optimizer.param_groups[0]['lr'], epoch)

        return avg_epoch_loss

    def validate(self, epoch):
        """验证"""
        self.model.eval()

        val_loss = 0
        num_batches = len(self.val_loader)

        print(f"\n开始验证...")

        with torch.no_grad():
            for batch_idx, (images, targets) in enumerate(self.val_loader):
                images = images.to(self.device)

                # 准备目标
                batch_targets = self._prepare_targets(targets)

                # 前向传播
                predictions = self.model(images)

                # 计算损失
                total_loss, _ = self.criterion(predictions, batch_targets)

                val_loss += total_loss.item()

                # 打印进度
                if (batch_idx + 1) % max(1, num_batches // 5) == 0:
                    progress = (batch_idx + 1) / num_batches * 100
                    print(f"  验证进度: {progress:5.1f}%")

        avg_val_loss = val_loss / num_batches

        print(f"验证完成: 平均损失 = {avg_val_loss:.4f}")

        # 记录到TensorBoard
        self.writer.add_scalar('Loss/val_total', avg_val_loss, epoch)

        # 保存最佳模型
        if avg_val_loss < self.best_val_loss:
            self.best_val_loss = avg_val_loss
            self._save_checkpoint(epoch, avg_val_loss, is_best=True)
            print(f"  ✓ 保存最佳模型 (损失: {avg_val_loss:.4f})")

        return avg_val_loss

    def _prepare_targets(self, targets):
        """准备目标数据"""
        batch_boxes = []
        batch_masks = []
        batch_labels = []

        for target in targets:
            batch_boxes.append(target['boxes'].to(self.device))
            batch_masks.append(target['masks'].to(self.device))
            batch_labels.append(target['labels'].to(self.device))

        # 处理空目标的情况
        if len(batch_boxes) == 0 or all(len(b) == 0 for b in batch_boxes):
            # 创建空的占位符
            batch_targets = {
                'bbox': torch.zeros((0, 4), device=self.device),
                'mask': torch.zeros((1, self.args.img_size, self.args.img_size), device=self.device),
                'cls': torch.zeros((0,), device=self.device, dtype=torch.long)
            }
        else:
            batch_targets = {
                'bbox': torch.cat(batch_boxes, dim=0),
                'mask': torch.cat(batch_masks, dim=0),
                'cls': torch.cat(batch_labels, dim=0)
            }

        return batch_targets

    def _save_checkpoint(self, epoch, val_loss, is_best=False):
        """保存检查点"""
        checkpoint = {
            'epoch': epoch,
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict() if self.scheduler else None,
            'val_loss': val_loss,
            'best_val_loss': self.best_val_loss,
            'args': vars(self.args)
        }

        if is_best:
            checkpoint_path = self.save_dir / 'best_model.pth'
        else:
            checkpoint_path = self.save_dir / f'checkpoint_epoch_{epoch + 1}.pth'

        torch.save(checkpoint, checkpoint_path)

        # 同时保存模型的配置信息
        if is_best:
            config_info = {
                'model_name': 'YOLOv9_Catenary',
                'num_classes': self.args.num_classes,
                'img_size': self.args.img_size,
                'training_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'training_args': vars(self.args)
            }

            config_path = self.save_dir / 'model_config.yaml'
            with open(config_path, 'w') as f:
                yaml.dump(config_info, f, default_flow_style=False)

    def run(self):
        """运行训练"""
        global val_loss
        print(f"\n{'=' * 60}")
        print(f"开始训练，共 {self.args.epochs} 个epoch")
        print(f"{'=' * 60}")

        start_time = time.time()

        for epoch in range(self.current_epoch, self.args.epochs):
            # 训练
            self.train_epoch(epoch)

            # 验证
            val_loss = self.validate(epoch)

            # 更新学习率
            if self.scheduler is not None:
                if isinstance(self.scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau):
                    self.scheduler.step(val_loss)
                else:
                    self.scheduler.step()

            # 定期保存检查点
            if (epoch + 1) % self.args.save_interval == 0:
                self._save_checkpoint(epoch, val_loss, is_best=False)

            print(f"{'=' * 60}\n")

        # 训练完成
        total_time = time.time() - start_time
        print(f"{'=' * 60}")
        print(f"训练完成!")
        print(f"总训练时间: {total_time:.1f}秒 ({total_time / 3600:.1f}小时)")
        print(f"最佳验证损失: {self.best_val_loss:.4f}")
        print(f"模型保存在: {self.save_dir}")
        print(f"{'=' * 60}")

        # 保存最终模型
        final_checkpoint = {
            'epoch': self.args.epochs,
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'val_loss': val_loss,
            'best_val_loss': self.best_val_loss,
            'args': vars(self.args)
        }

        final_path = self.save_dir / 'final_model.pth'
        torch.save(final_checkpoint, final_path)
        print(f"最终模型已保存: {final_path}")


def main(args):
    """主训练函数"""
    # 设置随机种子
    if args.seed is not None:
        torch.manual_seed(args.seed)
        torch.cuda.manual_seed(args.seed)
        torch.cuda.manual_seed_all(args.seed)
        np.random.seed(args.seed)
        random.seed(args.seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

    # 设置设备
    if args.device == 'auto':
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    else:
        device = torch.device(args.device)

    print(f"使用设备: {device}")
    if device.type == 'cuda':
        print(f"GPU名称: {torch.cuda.get_device_name(0)}")
        print(f"GPU内存: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")

    # 加载数据集配置
    data_config = load_data_config(args.data_config)

    # 覆盖数据集路径（如果提供了--data-dir）
    if args.data_dir:
        data_path = Path(args.data_dir)
        data_config['train'] = str(data_path / 'train/images')
        data_config['val'] = str(data_path / 'val/images')

    # 创建数据增强
    if args.augment:
        train_transform = DataAugmentation.get_train_transform()
    else:
        train_transform = DataAugmentation.get_val_transform()

    # 创建数据集
    print(f"\n创建数据集...")

    train_dataset = CatenaryDataset(
        images_dir=data_config['train'],
        img_size=args.img_size,
        transform=train_transform,
        augment=args.augment,
        cache=args.cache_images
    )

    val_dataset = CatenaryDataset(
        images_dir=data_config['val'],
        img_size=args.img_size,
        transform=DataAugmentation.get_val_transform(),
        augment=False,
        cache=args.cache_images_val
    )

    print(f"训练集大小: {len(train_dataset)}")
    print(f"验证集大小: {len(val_dataset)}")

    # 创建数据加载器
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=0,
        pin_memory=True,
        collate_fn=collate_fn,
        drop_last=True
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=0,
        pin_memory=True,
        collate_fn=collate_fn
    )

    # 创建模型
    print(f"\n创建模型...")
    model = YOLOv9_Catenary(nc=args.num_classes).to(device)

    # 打印模型信息
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"模型参数总数: {total_params:,}")
    print(f"可训练参数: {trainable_params:,}")

    # 损失函数
    criterion = CatenaryLoss(
        alpha=args.focal_alpha,
        gamma=args.focal_gamma,
        lambda_cls=args.lambda_cls,
        lambda_reg=args.lambda_reg,
        lambda_mask=args.lambda_mask,
        lambda_boundary=args.lambda_boundary
    )

    # 优化器
    if args.optimizer == 'adamw':
        optimizer = optim.AdamW(
            model.parameters(),
            lr=args.lr,
            weight_decay=args.weight_decay,
            betas=(0.9, 0.999)
        )
    elif args.optimizer == 'adam':
        optimizer = optim.Adam(
            model.parameters(),
            lr=args.lr,
            weight_decay=args.weight_decay
        )
    else:  # sgd
        optimizer = optim.SGD(
            model.parameters(),
            lr=args.lr,
            momentum=0.9,
            weight_decay=args.weight_decay,
            nesterov=True
        )

    # 学习率调度器
    if args.scheduler == 'cosine':
        scheduler = optim.lr_scheduler.CosineAnnealingLR(
            optimizer,
            T_max=args.epochs,
            eta_min=args.lr_min
        )
    elif args.scheduler == 'plateau':
        scheduler = optim.lr_scheduler.ReduceLROnPlateau(
            optimizer,
            mode='min',
            factor=0.5,
            patience=5,
            verbose=True
        )
    elif args.scheduler == 'step':
        scheduler = optim.lr_scheduler.StepLR(
            optimizer,
            step_size=args.lr_step,
            gamma=0.1
        )
    else:
        scheduler = None

    # TensorBoard
    log_dir = Path(args.log_dir) / datetime.now().strftime('%Y%m%d_%H%M%S')
    log_dir.mkdir(parents=True, exist_ok=True)
    writer = SummaryWriter(log_dir=log_dir)

    print(f"TensorBoard日志目录: {log_dir}")

    # 创建训练器
    trainer = Trainer(
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        criterion=criterion,
        optimizer=optimizer,
        scheduler=scheduler,
        device=device,
        args=args,
        writer=writer
    )

    # 加载检查点（如果提供）
    if args.resume:
        checkpoint_path = Path(args.resume)
        if checkpoint_path.exists():
            print(f"从检查点恢复: {checkpoint_path}")
            checkpoint = torch.load(checkpoint_path, map_location=device)

            model.load_state_dict(checkpoint['model_state_dict'])
            optimizer.load_state_dict(checkpoint['optimizer_state_dict'])

            if scheduler is not None and checkpoint.get('scheduler_state_dict'):
                scheduler.load_state_dict(checkpoint['scheduler_state_dict'])

            trainer.current_epoch = checkpoint['epoch']
            trainer.best_val_loss = checkpoint.get('best_val_loss', float('inf'))

            print(f"恢复训练，从epoch {trainer.current_epoch + 1} 开始")
        else:
            print(f"警告: 检查点文件不存在 {checkpoint_path}")

    # 开始训练
    try:
        trainer.run()
    except KeyboardInterrupt:
        print("\n训练被用户中断")
    except Exception as e:
        print(f"\n训练过程中发生错误: {e}")
        import traceback
        traceback.print_exc()
    finally:
        writer.close()
        print(f"\n训练完成。TensorBoard日志保存在: {log_dir}")
        print(f"运行以下命令查看日志:")
        print(f"  tensorboard --logdir {log_dir.parent}")

    return trainer.best_val_loss


def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description='训练YOLOv9接触网异物检测模型')

    # 数据参数
    parser.add_argument('--data-config', type=str, default='data/catenary.yaml',
                        help='数据集配置文件路径')
    parser.add_argument('--data-dir', type=str, help='数据集目录（覆盖配置文件中的路径）')
    parser.add_argument('--num-classes', type=int, default=2, help='类别数')
    parser.add_argument('--img-size', type=int, default=640, help='输入图像尺寸')

    # 训练参数
    parser.add_argument('--epochs', type=int, default=100, help='训练轮数')
    parser.add_argument('--batch-size', type=int, default=4, help='批次大小')
    parser.add_argument('--lr', type=float, default=0.001, help='初始学习率')
    parser.add_argument('--lr-min', type=float, default=1e-6, help='最小学习率')
    parser.add_argument('--lr-step', type=int, default=30, help='学习率衰减步长')
    parser.add_argument('--weight-decay', type=float, default=0.05, help='权重衰减')
    parser.add_argument('--optimizer', type=str, default='adamw',
                        choices=['adamw', 'adam', 'sgd'], help='优化器')
    parser.add_argument('--scheduler', type=str, default='cosine',
                        choices=['cosine', 'plateau', 'step', 'none'], help='学习率调度器')

    # 损失函数参数
    parser.add_argument('--focal-alpha', type=float, default=0.25, help='Focal loss alpha')
    parser.add_argument('--focal-gamma', type=float, default=2.0, help='Focal loss gamma')
    parser.add_argument('--lambda-cls', type=float, default=1.0, help='分类损失权重')
    parser.add_argument('--lambda-reg', type=float, default=1.0, help='回归损失权重')
    parser.add_argument('--lambda-mask', type=float, default=1.0, help='掩码损失权重')
    parser.add_argument('--lambda-boundary', type=float, default=0.5, help='边界损失权重')

    # 硬件参数
    parser.add_argument('--device', type=str, default='auto',
                        choices=['auto', 'cuda', 'cpu'], help='训练设备')
    parser.add_argument('--num-workers', type=int, default=4, help='数据加载线程数')
    parser.add_argument('--cache-images', action='store_true', help='缓存训练图像到内存')
    parser.add_argument('--cache-images-val', action='store_true', help='缓存验证图像到内存')

    # 数据增强
    parser.add_argument('--augment', action='store_true', help='启用数据增强')
    parser.add_argument('--no-augment', dest='augment', action='store_false',
                        help='禁用数据增强')
    parser.set_defaults(augment=True)

    # 训练控制
    parser.add_argument('--grad-clip', type=float, default=10.0, help='梯度裁剪阈值')
    parser.add_argument('--print-freq', type=int, default=10, help='打印频率')
    parser.add_argument('--seed', type=int, default=42, help='随机种子')

    # 保存和日志
    parser.add_argument('--save-dir', type=str, default='./runs', help='模型保存路径')
    parser.add_argument('--log-dir', type=str, default='./logs', help='TensorBoard日志路径')
    parser.add_argument('--save-interval', type=int, default=10, help='保存检查点的间隔（epoch）')
    parser.add_argument('--resume', type=str, help='从检查点恢复训练')

    return parser.parse_args()


if __name__ == '__main__':
    # 解析参数
    args = parse_args()

    # 打印配置
    print(f"{'=' * 60}")
    print(f"YOLOv9接触网异物检测 - 训练脚本")
    print(f"{'=' * 60}")
    print(f"训练配置:")
    for arg in vars(args):
        print(f"  {arg}: {getattr(args, arg)}")
    print(f"{'=' * 60}")

    # 开始训练
    best_val_loss = main(args)

    print(f"\n训练脚本执行完成!")
    print(f"最佳验证损失: {best_val_loss:.4f}")
    print(f"运行以下命令查看训练日志:")
    print(f"  tensorboard --logdir {args.log_dir}")