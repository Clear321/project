# setup_project.py（更新版）
import os
from pathlib import Path


def create_project_structure():
    """创建完整的项目结构"""
    project_name = "yolov9_catenary"

    # 定义目录结构
    directories = [
        "data",
        "models",
        "utils",
        "scripts",
        "runs",
        "logs",
        "results",
        "evaluation",
        "datasets/catenary/train/images",
        "datasets/catenary/train/labels",
        "datasets/catenary/val/images",
        "datasets/catenary/val/labels",
        "datasets/catenary/test/images",
        "datasets/catenary/test/labels",
        "datasets/catenary_synthetic",
        "datasets/catenary_minimal",
        "datasets/raw/images",
        "datasets/raw/labels",
    ]

    # 创建目录
    print("正在创建项目目录结构...")
    for directory in directories:
        dir_path = Path(directory)
        dir_path.mkdir(parents=True, exist_ok=True)
        print(f"✓ 创建目录: {directory}")

    # 创建__init__.py文件
    init_dirs = ["models", "utils", "scripts"]
    for dir_name in init_dirs:
        init_file = Path(dir_name) / "__init__.py"
        init_file.write_text(f"# {dir_name} package\n")
        print(f"✓ 创建包: {init_file}")

    # 创建配置文件
    config_files = {
        "data/catenary.yaml": """# 接触网异物检测数据集配置
path: ./datasets/catenary
train: train/images
val: val/images
test: test/images

nc: 2
names: ['background', 'foreign_object']
""",

        "data/catenary_minimal.yaml": """# 最小测试数据集配置
path: ./datasets/catenary_minimal
train: train/images
val: val/images
test: test/images

nc: 2
names: ['background', 'foreign_object']
""",

        "config.py": """# 配置文件
import argparse

def get_train_args():
    \"\"\"获取训练参数\"\"\"
    parser = argparse.ArgumentParser(description='训练配置')

    # 数据参数
    parser.add_argument('--data-dir', type=str, default='./datasets/catenary', 
                       help='数据集路径')
    parser.add_argument('--data-config', type=str, default='data/catenary.yaml',
                       help='数据集配置文件')
    parser.add_argument('--num-classes', type=int, default=2, help='类别数')
    parser.add_argument('--img-size', type=int, default=640, help='图像尺寸')

    # 训练参数
    parser.add_argument('--epochs', type=int, default=100, help='训练轮数')
    parser.add_argument('--batch-size', type=int, default=4, help='批次大小')
    parser.add_argument('--lr', type=float, default=0.001, help='学习率')
    parser.add_argument('--weight-decay', type=float, default=0.05, help='权重衰减')

    return parser.parse_args()
""",
    }

    # 创建配置文件
    print("\n正在创建配置文件...")
    for file_path, content in config_files.items():
        file = Path(file_path)
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_text(content, encoding='utf-8')
        print(f"✓ 创建文件: {file_path}")

    # 创建示例数据集
    print("\n正在创建示例数据集...")
    from utils.dataset_tools import DatasetCreator
    DatasetCreator.create_minimal_dataset()

    print(f"\n✅ 项目 '{project_name}' 创建完成！")
    print("\n快速开始:")
    print("1. 安装依赖: pip install -r requirements.txt")
    print("2. 创建数据集: python scripts/create_dataset.py")
    print("3. 训练模型: python train.py --data-config data/catenary_minimal.yaml")
    print("4. 检测异物: python detect.py --model-path ./runs/best_model.pth")


if __name__ == "__main__":
    create_project_structure()